import type { CustomFieldTemplate } from '../../../types/models';
import { createId } from '../../../utils/createId';
import type { ContactFormCustomField } from '../data/contactRepository';
import type { ContactCustomFieldDetail } from '../types';

export function buildContactFormCustomFields(
  templates: CustomFieldTemplate[],
  existingFields: ContactCustomFieldDetail[] = [],
): ContactFormCustomField[] {
  const result: ContactFormCustomField[] = existingFields.map((field) => ({ ...field }));
  const existingTemplateIds = new Set(
    existingFields.map((field) => field.templateId).filter((id): id is string => Boolean(id)),
  );

  for (const template of templates) {
    if (!existingTemplateIds.has(template.id)) {
      result.push({
        id: createId('custom'),
        templateId: template.id,
        fieldKey: template.fieldKey,
        fieldLabel: template.label,
        value: '',
        valueType: template.valueType,
      });
    }
  }

  return result;
}
