import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { useFocusEffect } from '@react-navigation/native';
import { useCallback } from 'react';
import { useSQLiteContext } from 'expo-sqlite';

import { AppHeader, AppScreen, IconButton } from '../../../components';
import { useI18n } from '../../../i18n';
import type { ProfileStackParamList } from '../../../types/navigation';
import { UserProfileForm } from '../components/UserProfileForm';
import { saveUserProfile, type UserProfileInput } from '../data/userProfileRepository';
import { useUserProfile } from '../hooks/useUserProfile';

type EditUserProfileScreenProps = NativeStackScreenProps<ProfileStackParamList, 'EditUserProfile'>;

const emptyProfile: UserProfileInput = {
  fullName: '',
  phone: '',
  email: '',
  company: '',
  title: '',
  linkedinUrl: '',
  notes: '',
};

export function EditUserProfileScreen({ navigation }: EditUserProfileScreenProps) {
  const { t } = useI18n();
  const database = useSQLiteContext();
  const { profile, reload } = useUserProfile();

  useFocusEffect(useCallback(() => { void reload(); }, [reload]));

  const initialValues: UserProfileInput = profile
    ? {
        fullName: profile.fullName,
        phone: profile.phone ?? '',
        email: profile.email ?? '',
        company: profile.company ?? '',
        title: profile.title ?? '',
        linkedinUrl: profile.linkedinUrl ?? '',
        notes: profile.notes ?? '',
      }
    : emptyProfile;

  const submit = async (values: UserProfileInput) => {
    await saveUserProfile(database, values);
    navigation.goBack();
  };

  return (
    <AppScreen scrollable>
      <AppHeader
        leading={<IconButton accessibilityLabel={t('userProfile.back')} icon="arrow-back" onPress={navigation.goBack} />}
        subtitle={t('userProfile.editSubtitle')}
        title={profile ? t('userProfile.editTitle') : t('userProfile.createTitle')}
      />
      <UserProfileForm
        key={profile?.updatedAt ?? 'new-profile'}
        initialValues={initialValues}
        onSubmit={submit}
      />
    </AppScreen>
  );
}
