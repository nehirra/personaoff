import { SQLiteProvider } from 'expo-sqlite';
import { StatusBar } from 'react-native';

import { RootNavigator } from './src/app/RootNavigator';
import { DATABASE_NAME, initializeDatabase } from './src/db/database';
import { I18nProvider } from './src/i18n';

export default function App() {
  return (
    <I18nProvider>
      <SQLiteProvider databaseName={DATABASE_NAME} onInit={initializeDatabase}>
        <StatusBar barStyle="default" />
        <RootNavigator />
      </SQLiteProvider>
    </I18nProvider>
  );
}
