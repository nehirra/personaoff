import type { SQLiteDatabase } from 'expo-sqlite';

import { createId } from '../../../utils/createId';
import type { ImportedContactValue, ImportedDeviceContact } from '../services/deviceContactsService';

export type MergeValueChoice = 'existing' | 'imported' | 'both';

export type ExistingImportMatch = {
  id: string;
  fullName: string;
  company: string | null;
  title: string | null;
  phones: ImportedContactValue[];
  emails: ImportedContactValue[];
};

export type DuplicateImportItem = {
  id: string;
  imported: ImportedDeviceContact;
  existing: ExistingImportMatch;
  phoneConflict: boolean;
  emailConflict: boolean;
};

export type PreparedImport = {
  duplicates: DuplicateImportItem[];
  newContacts: ImportedDeviceContact[];
};

export type ImportDecision = {
  action: 'merge' | 'separate';
  phoneChoice?: MergeValueChoice;
  emailChoice?: MergeValueChoice;
};

export type ImportSummary = {
  added: number;
  merged: number;
  total: number;
};

type ExistingContactRow = {
  id: string;
  fullName: string;
  company: string | null;
  title: string | null;
};

type ExistingValueRow = {
  contactId: string;
  label: string | null;
  value: string;
};

function normalizePhone(value: string): string {
  const trimmed = value.trim();
  const digits = trimmed.replace(/\D/g, '');
  return trimmed.startsWith('+') && digits ? `+${digits}` : digits;
}

function normalizeEmail(value: string): string {
  return value.trim().toLocaleLowerCase();
}

function normalizedSet(values: ImportedContactValue[], type: 'phone' | 'email'): Set<string> {
  return new Set(
    values
      .map((item) => (type === 'phone' ? normalizePhone(item.value) : normalizeEmail(item.value)))
      .filter(Boolean),
  );
}

function setsEqual(first: Set<string>, second: Set<string>): boolean {
  return first.size === second.size && [...first].every((value) => second.has(value));
}

export async function prepareContactImport(
  database: SQLiteDatabase,
  importedContacts: ImportedDeviceContact[],
): Promise<PreparedImport> {
  const [contacts, phones, emails] = await Promise.all([
    database.getAllAsync<ExistingContactRow>('SELECT id, fullName, company, title FROM Contact'),
    database.getAllAsync<ExistingValueRow>('SELECT contactId, label, value FROM ContactPhone'),
    database.getAllAsync<ExistingValueRow>('SELECT contactId, label, value FROM ContactEmail'),
  ]);

  const phonesByContact = new Map<string, ImportedContactValue[]>();
  const emailsByContact = new Map<string, ImportedContactValue[]>();
  for (const phone of phones) {
    phonesByContact.set(phone.contactId, [
      ...(phonesByContact.get(phone.contactId) ?? []),
      { label: phone.label, value: phone.value },
    ]);
  }
  for (const email of emails) {
    emailsByContact.set(email.contactId, [
      ...(emailsByContact.get(email.contactId) ?? []),
      { label: email.label, value: email.value },
    ]);
  }

  const existingContacts: ExistingImportMatch[] = contacts.map((contact) => ({
    ...contact,
    phones: phonesByContact.get(contact.id) ?? [],
    emails: emailsByContact.get(contact.id) ?? [],
  }));
  const phoneOwners = new Map<string, ExistingImportMatch[]>();
  const emailOwners = new Map<string, ExistingImportMatch[]>();

  for (const contact of existingContacts) {
    for (const phone of normalizedSet(contact.phones, 'phone')) {
      phoneOwners.set(phone, [...(phoneOwners.get(phone) ?? []), contact]);
    }
    for (const email of normalizedSet(contact.emails, 'email')) {
      emailOwners.set(email, [...(emailOwners.get(email) ?? []), contact]);
    }
  }

  const result: PreparedImport = { duplicates: [], newContacts: [] };
  for (const imported of importedContacts) {
    const scores = new Map<string, { contact: ExistingImportMatch; score: number }>();
    for (const phone of normalizedSet(imported.phones, 'phone')) {
      for (const owner of phoneOwners.get(phone) ?? []) {
        scores.set(owner.id, { contact: owner, score: (scores.get(owner.id)?.score ?? 0) + 1 });
      }
    }
    for (const email of normalizedSet(imported.emails, 'email')) {
      for (const owner of emailOwners.get(email) ?? []) {
        scores.set(owner.id, { contact: owner, score: (scores.get(owner.id)?.score ?? 0) + 1 });
      }
    }

    const bestMatch = [...scores.values()].sort((a, b) => b.score - a.score)[0]?.contact;
    if (!bestMatch) {
      result.newContacts.push(imported);
      continue;
    }

    const existingPhones = normalizedSet(bestMatch.phones, 'phone');
    const importedPhones = normalizedSet(imported.phones, 'phone');
    const existingEmails = normalizedSet(bestMatch.emails, 'email');
    const importedEmails = normalizedSet(imported.emails, 'email');
    result.duplicates.push({
      id: imported.sourceId,
      imported,
      existing: bestMatch,
      phoneConflict:
        existingPhones.size > 0 && importedPhones.size > 0 && !setsEqual(existingPhones, importedPhones),
      emailConflict:
        existingEmails.size > 0 && importedEmails.size > 0 && !setsEqual(existingEmails, importedEmails),
    });
  }

  return result;
}

export function isImportDecisionComplete(
  item: DuplicateImportItem,
  decision: ImportDecision | undefined,
): boolean {
  if (!decision) return false;
  if (decision.action === 'separate') return true;
  if (item.phoneConflict && !decision.phoneChoice) return false;
  if (item.emailConflict && !decision.emailChoice) return false;
  return true;
}

async function insertTemplateSlots(
  database: SQLiteDatabase,
  contactId: string,
  timestamp: string,
): Promise<void> {
  await database.runAsync(
    `INSERT OR IGNORE INTO ContactCustomFieldValue
     (id, contactId, templateId, fieldKey, fieldLabel, value, valueType, position, createdAt, updatedAt)
     SELECT 'custom_' || lower(hex(randomblob(16))), ?, id, fieldKey, label, NULL, valueType, position, ?, ?
     FROM CustomFieldTemplate WHERE isActive = 1`,
    contactId,
    timestamp,
    timestamp,
  );
}

async function insertImportedContact(
  database: SQLiteDatabase,
  imported: ImportedDeviceContact,
  timestamp: string,
): Promise<string> {
  const contactId = createId('contact');
  await database.runAsync(
    `INSERT INTO Contact
     (id, fullName, company, title, meetingContext, linkedinUrl, photoUri, notes, createdAt, updatedAt)
     VALUES (?, ?, ?, ?, NULL, NULL, NULL, NULL, ?, ?)`,
    contactId,
    imported.fullName,
    imported.company,
    imported.title,
    timestamp,
    timestamp,
  );
  for (const [index, phone] of imported.phones.entries()) {
    await database.runAsync(
      `INSERT INTO ContactPhone (id, contactId, value, label, isPrimary, createdAt, updatedAt)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      createId('phone'), contactId, phone.value, phone.label, index === 0 ? 1 : 0, timestamp, timestamp,
    );
  }
  for (const [index, email] of imported.emails.entries()) {
    await database.runAsync(
      `INSERT INTO ContactEmail (id, contactId, value, label, isPrimary, createdAt, updatedAt)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      createId('email'), contactId, email.value, email.label, index === 0 ? 1 : 0, timestamp, timestamp,
    );
  }
  await insertTemplateSlots(database, contactId, timestamp);
  return contactId;
}

async function mergeValues(
  database: SQLiteDatabase,
  table: 'ContactPhone' | 'ContactEmail',
  idPrefix: 'phone' | 'email',
  contactId: string,
  existingValues: ImportedContactValue[],
  importedValues: ImportedContactValue[],
  choice: MergeValueChoice,
  timestamp: string,
): Promise<void> {
  if (choice === 'existing') return;
  if (choice === 'imported') {
    await database.runAsync(`DELETE FROM ${table} WHERE contactId = ?`, contactId);
  }

  const normalize = table === 'ContactPhone' ? normalizePhone : normalizeEmail;
  const seen = new Set(
    (choice === 'both' ? existingValues : []).map((item) => normalize(item.value)).filter(Boolean),
  );
  for (const imported of importedValues) {
    const normalized = normalize(imported.value);
    if (!normalized || seen.has(normalized)) continue;
    const primary = seen.size === 0 ? 1 : 0;
    await database.runAsync(
      `INSERT INTO ${table} (id, contactId, value, label, isPrimary, createdAt, updatedAt)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      createId(idPrefix), contactId, imported.value, imported.label, primary, timestamp, timestamp,
    );
    seen.add(normalized);
  }
}

export async function applyPreparedImport(
  database: SQLiteDatabase,
  prepared: PreparedImport,
  decisions: Record<string, ImportDecision>,
): Promise<ImportSummary> {
  if (!prepared.duplicates.every((item) => isImportDecisionComplete(item, decisions[item.id]))) {
    throw new Error('Import decisions are incomplete');
  }

  const timestamp = new Date().toISOString();
  let added = 0;
  let merged = 0;

  await database.withTransactionAsync(async () => {
    for (const imported of prepared.newContacts) {
      await insertImportedContact(database, imported, timestamp);
      added += 1;
    }

    for (const item of prepared.duplicates) {
      const decision = decisions[item.id];
      if (decision.action === 'separate') {
        await insertImportedContact(database, item.imported, timestamp);
        added += 1;
        continue;
      }

      await database.runAsync(
        `UPDATE Contact SET
           company = COALESCE(NULLIF(TRIM(company), ''), ?),
           title = COALESCE(NULLIF(TRIM(title), ''), ?),
           updatedAt = ?
         WHERE id = ?`,
        item.imported.company,
        item.imported.title,
        timestamp,
        item.existing.id,
      );
      await mergeValues(
        database, 'ContactPhone', 'phone', item.existing.id, item.existing.phones,
        item.imported.phones, decision.phoneChoice ?? 'both', timestamp,
      );
      await mergeValues(
        database, 'ContactEmail', 'email', item.existing.id, item.existing.emails,
        item.imported.emails, decision.emailChoice ?? 'both', timestamp,
      );
      merged += 1;
    }
  });

  return { added, merged, total: added + merged };
}
