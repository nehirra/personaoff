import { Ionicons } from '@expo/vector-icons';
import type { ComponentProps } from 'react';
import { StyleSheet, Text, View } from 'react-native';

import { colors, radius, spacing, typography } from '../app/theme';
import { PrimaryButton } from './PrimaryButton';

type EmptyStateProps = {
  actionLabel?: string;
  description: string;
  icon?: ComponentProps<typeof Ionicons>['name'];
  onAction?: () => void;
  title: string;
};

export function EmptyState({ actionLabel, description, icon = 'people-outline', onAction, title }: EmptyStateProps) {
  return (
    <View style={styles.container}>
      <View style={styles.iconSurface}>
        <Ionicons color={colors.primary} name={icon} size={30} />
      </View>
      <Text style={styles.title}>{title}</Text>
      <Text style={styles.description}>{description}</Text>
      {actionLabel && onAction ? (
        <View style={styles.action}><PrimaryButton label={actionLabel} onPress={onAction} /></View>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderColor: colors.border,
    borderRadius: radius.lg,
    borderWidth: 1,
    padding: spacing.xl,
  },
  iconSurface: {
    alignItems: 'center',
    backgroundColor: colors.primarySoft,
    borderRadius: radius.pill,
    height: 64,
    justifyContent: 'center',
    width: 64,
  },
  title: { color: colors.text, fontSize: typography.section, fontWeight: '700', marginTop: spacing.lg, textAlign: 'center' },
  description: { color: colors.textMuted, fontSize: typography.body, lineHeight: 23, marginTop: spacing.sm, textAlign: 'center' },
  action: { marginTop: spacing.xl, minWidth: 180 },
});
