import type { NavigatorScreenParams } from '@react-navigation/native';

export type ContactsStackParamList = {
  ContactList: undefined;
  ContactDetail: { contactId: string };
  EditContact: { contactId: string };
  ImportReview: { sessionId: string };
};

export type ProfileStackParamList = {
  ProfileHome: undefined;
  EditUserProfile: undefined;
  Backup: undefined;
};

export type RootTabParamList = {
  Contacts: NavigatorScreenParams<ContactsStackParamList> | undefined;
  Add: undefined;
  Profile: NavigatorScreenParams<ProfileStackParamList> | undefined;
};
