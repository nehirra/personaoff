import type { SQLiteDatabase } from 'expo-sqlite';

import type { UserProfile } from '../../../types/models';

export type UserProfileInput = {
  fullName: string;
  phone: string;
  email: string;
  company: string;
  title: string;
  linkedinUrl: string;
  notes: string;
};

const LOCAL_PROFILE_ID = 'local-user-profile';

function optionalValue(value: string): string | null {
  const trimmed = value.trim();
  return trimmed || null;
}

export async function getUserProfile(database: SQLiteDatabase): Promise<UserProfile | null> {
  return database.getFirstAsync<UserProfile>(
    `SELECT id, fullName, company, title, phone, email, linkedinUrl, photoUri, notes, createdAt, updatedAt
     FROM UserProfile
     ORDER BY updatedAt DESC
     LIMIT 1`,
  );
}

export async function saveUserProfile(
  database: SQLiteDatabase,
  input: UserProfileInput,
): Promise<UserProfile> {
  const existing = await getUserProfile(database);
  const timestamp = new Date().toISOString();
  const id = existing?.id ?? LOCAL_PROFILE_ID;

  await database.withTransactionAsync(async () => {
    if (existing) {
      await database.runAsync(
        `UPDATE UserProfile SET
           fullName = ?, phone = ?, email = ?, company = ?, title = ?, linkedinUrl = ?, notes = ?, updatedAt = ?
         WHERE id = ?`,
        input.fullName.trim(),
        optionalValue(input.phone),
        optionalValue(input.email),
        optionalValue(input.company),
        optionalValue(input.title),
        optionalValue(input.linkedinUrl),
        optionalValue(input.notes),
        timestamp,
        id,
      );
    } else {
      await database.runAsync(
        `INSERT INTO UserProfile
         (id, fullName, company, title, phone, email, linkedinUrl, photoUri, notes, createdAt, updatedAt)
         VALUES (?, ?, ?, ?, ?, ?, ?, NULL, ?, ?, ?)`,
        id,
        input.fullName.trim(),
        optionalValue(input.company),
        optionalValue(input.title),
        optionalValue(input.phone),
        optionalValue(input.email),
        optionalValue(input.linkedinUrl),
        optionalValue(input.notes),
        timestamp,
        timestamp,
      );
    }
  });

  const savedProfile = await getUserProfile(database);
  if (!savedProfile) throw new Error('Profile could not be read after saving');
  return savedProfile;
}
