import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { DefaultTheme, NavigationContainer } from '@react-navigation/native';

import { AddScreen } from '../features/contacts/screens/AddScreen';
import { ContactsNavigator } from '../features/contacts/navigation/ContactsNavigator';
import { ProfileNavigator } from '../features/profile/navigation/ProfileNavigator';
import { useI18n } from '../i18n';
import type { RootTabParamList } from '../types/navigation';
import { colors } from './theme';

const Tab = createBottomTabNavigator<RootTabParamList>();

const theme = {
  ...DefaultTheme,
  colors: {
    ...DefaultTheme.colors,
    primary: colors.primary,
    background: colors.background,
    card: colors.surface,
    text: colors.text,
    border: colors.border,
  },
};

export function RootNavigator() {
  const { t } = useI18n();

  return (
    <NavigationContainer theme={theme}>
      <Tab.Navigator
        initialRouteName="Contacts"
        screenOptions={{
          headerShown: false,
          tabBarActiveTintColor: colors.primary,
          tabBarInactiveTintColor: colors.textMuted,
          tabBarLabelStyle: { fontSize: 12, fontWeight: '600' },
          tabBarStyle: { backgroundColor: colors.surface, borderTopColor: colors.border, height: 64, paddingBottom: 8, paddingTop: 6 },
        }}
      >
        <Tab.Screen
          name="Contacts"
          component={ContactsNavigator}
          options={{
            title: t('tabs.contacts'),
            tabBarIcon: ({ color, size }) => <Ionicons color={color} name="people-outline" size={size} />,
          }}
        />
        <Tab.Screen
          name="Add"
          component={AddScreen}
          options={{
            title: t('tabs.add'),
            tabBarIcon: ({ color, size }) => <Ionicons color={color} name="add-circle-outline" size={size} />,
          }}
        />
        <Tab.Screen
          name="Profile"
          component={ProfileNavigator}
          options={{
            title: t('tabs.profile'),
            tabBarIcon: ({ color, size }) => <Ionicons color={color} name="person-outline" size={size} />,
          }}
        />
      </Tab.Navigator>
    </NavigationContainer>
  );
}
