import { createNativeStackNavigator } from '@react-navigation/native-stack';

import type { ContactsStackParamList } from '../../../types/navigation';
import { ContactDetailScreen } from '../screens/ContactDetailScreen';
import { ContactsScreen } from '../screens/ContactsScreen';
import { EditContactScreen } from '../screens/EditContactScreen';
import { ImportReviewScreen } from '../screens/ImportReviewScreen';

const Stack = createNativeStackNavigator<ContactsStackParamList>();

export function ContactsNavigator() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="ContactList" component={ContactsScreen} />
      <Stack.Screen name="ContactDetail" component={ContactDetailScreen} />
      <Stack.Screen name="EditContact" component={EditContactScreen} />
      <Stack.Screen name="ImportReview" component={ImportReviewScreen} />
    </Stack.Navigator>
  );
}
