# Smart Contacts App

Offline-first contact management application for iOS and Android, built with Expo, React Native, TypeScript, and SQLite.

## Commands

```bash
npm install
npm start
```

Use `npm run android` or `npm run ios` to open a platform target.

## Architecture

- `src/app`: application composition and navigation
- `src/features`: feature-owned screens and future domain logic
- `src/components`: reusable UI components
- `src/db`: SQLite connection, schema, and migrations
- `src/i18n`: localization configuration and resources
- `src/types`: shared TypeScript types
- `src/utils`: framework-independent helpers
