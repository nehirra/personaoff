import type { ReactNode } from 'react';
import { StyleSheet, Text, View } from 'react-native';

import { colors, spacing, typography } from '../app/theme';

type AppHeaderProps = {
  action?: ReactNode;
  leading?: ReactNode;
  subtitle?: string;
  title: string;
};

export function AppHeader({ action, leading, subtitle, title }: AppHeaderProps) {
  return (
    <View style={styles.container}>
      {leading ? <View style={styles.leading}>{leading}</View> : null}
      <View style={styles.copy}>
        <Text numberOfLines={2} style={styles.title}>
          {title}
        </Text>
        {subtitle ? (
          <Text numberOfLines={3} style={styles.subtitle}>
            {subtitle}
          </Text>
        ) : null}
      </View>
      {action ? <View style={styles.action}>{action}</View> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'flex-start',
    flexDirection: 'row',
    paddingBottom: spacing.xl,
    paddingTop: spacing.lg,
  },
  copy: { flex: 1, minWidth: 0 },
  leading: { marginRight: spacing.md },
  title: {
    color: colors.text,
    fontSize: typography.title,
    fontWeight: '700',
    letterSpacing: -0.5,
  },
  subtitle: {
    color: colors.textMuted,
    fontSize: typography.body,
    lineHeight: 23,
    marginTop: spacing.xs,
  },
  action: { marginLeft: spacing.md },
});
