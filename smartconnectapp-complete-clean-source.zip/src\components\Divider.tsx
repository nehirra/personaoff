import { StyleSheet, View } from 'react-native';

import { colors, spacing } from '../app/theme';

type DividerProps = { compact?: boolean };

export function Divider({ compact = false }: DividerProps) {
  return <View style={[styles.divider, compact && styles.compact]} />;
}

const styles = StyleSheet.create({
  divider: { backgroundColor: colors.border, height: StyleSheet.hairlineWidth, marginVertical: spacing.xl },
  compact: { marginVertical: 0 },
});
