import { getLocales } from 'expo-localization';
import { createContext, type PropsWithChildren, useContext, useMemo, useState } from 'react';

import { translations, type TranslationKey } from './translations';

export const supportedLocales = ['tr', 'en'] as const;
export type SupportedLocale = (typeof supportedLocales)[number];

type I18nContextValue = {
  locale: SupportedLocale;
  setLocale: (locale: SupportedLocale) => void;
  t: (key: TranslationKey) => string;
};

const I18nContext = createContext<I18nContextValue | null>(null);

export function getDeviceLocale(): SupportedLocale {
  const languageCode = getLocales()[0]?.languageCode;
  return languageCode === 'tr' || languageCode === 'en' ? languageCode : 'en';
}

export function I18nProvider({ children }: PropsWithChildren) {
  const [locale, setLocale] = useState<SupportedLocale>(getDeviceLocale);

  const value = useMemo<I18nContextValue>(
    () => ({
      locale,
      setLocale,
      t: (key) => translations[locale][key],
    }),
    [locale],
  );

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useI18n(): I18nContextValue {
  const context = useContext(I18nContext);

  if (!context) {
    throw new Error('useI18n must be used within I18nProvider');
  }

  return context;
}
