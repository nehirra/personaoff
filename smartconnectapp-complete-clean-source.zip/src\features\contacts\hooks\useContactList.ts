import { useCallback, useRef, useState } from 'react';
import { useSQLiteContext } from 'expo-sqlite';

import { getContacts } from '../data/contactRepository';
import type { ContactListItem } from '../types';

type ContactListState = {
  contacts: ContactListItem[];
  error: Error | null;
  loading: boolean;
};

export function useContactList(searchTerm: string) {
  const database = useSQLiteContext();
  const requestId = useRef(0);
  const [state, setState] = useState<ContactListState>({
    contacts: [],
    error: null,
    loading: true,
  });

  const reload = useCallback(async () => {
    const activeRequest = ++requestId.current;
    setState((current) => ({ ...current, error: null, loading: true }));

    try {
      const contacts = await getContacts(database, searchTerm);
      if (activeRequest === requestId.current) {
        setState({ contacts, error: null, loading: false });
      }
    } catch (cause) {
      if (activeRequest === requestId.current) {
        const error = cause instanceof Error ? cause : new Error(String(cause));
        setState((current) => ({ ...current, error, loading: false }));
      }
    }
  }, [database, searchTerm]);

  return { ...state, reload };
}
