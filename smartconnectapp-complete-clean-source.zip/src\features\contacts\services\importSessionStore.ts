import { createId } from '../../../utils/createId';
import type { ImportedDeviceContact } from './deviceContactsService';

const sessions = new Map<string, ImportedDeviceContact[]>();

export function createImportSession(contacts: ImportedDeviceContact[]): string {
  const sessionId = createId('import');
  sessions.set(sessionId, contacts);
  return sessionId;
}

export function getImportSession(sessionId: string): ImportedDeviceContact[] | null {
  return sessions.get(sessionId) ?? null;
}

export function deleteImportSession(sessionId: string): void {
  sessions.delete(sessionId);
}
