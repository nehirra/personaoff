import type { SQLiteDatabase } from 'expo-sqlite';

import type {
  Contact,
  ContactCustomFieldValue,
  ContactEmail,
  ContactMultiValue,
  ContactPhone,
  CustomFieldTemplate,
  UserProfile,
} from '../../../types/models';

export const BACKUP_SCHEMA = 'smart-contacts-offline-backup';
export const BACKUP_VERSION = 1;

export type SmartContactsBackup = {
  schema: typeof BACKUP_SCHEMA;
  version: typeof BACKUP_VERSION;
  exportedAt: string;
  app: { name: 'Smart Contacts'; version: string; direction: 'offline-to-online-compatible' };
  data: {
    contacts: Contact[];
    phones: ContactPhone[];
    emails: ContactEmail[];
    multiValues: ContactMultiValue[];
    customFieldTemplates: CustomFieldTemplate[];
    contactCustomFieldValues: ContactCustomFieldValue[];
    userProfiles: UserProfile[];
  };
};

export type RestoreMode = 'overwrite' | 'merge';

export type BackupCounts = {
  contacts: number;
  templates: number;
  profiles: number;
};

const arrayKeys = [
  'contacts',
  'phones',
  'emails',
  'multiValues',
  'customFieldTemplates',
  'contactCustomFieldValues',
  'userProfiles',
] as const;

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value) && typeof value === 'object' && !Array.isArray(value);
}

function hasString(row: unknown, key: string): boolean {
  return isRecord(row) && typeof row[key] === 'string' && Boolean((row[key] as string).trim());
}

export function parseBackupJson(raw: string): SmartContactsBackup {
  let parsed: unknown;
  try {
    parsed = JSON.parse(raw);
  } catch {
    throw new Error('INVALID_JSON');
  }
  if (!isRecord(parsed) || parsed.schema !== BACKUP_SCHEMA || parsed.version !== BACKUP_VERSION) {
    throw new Error('UNSUPPORTED_BACKUP');
  }
  const rawData = parsed.data;
  if (!isRecord(rawData) || arrayKeys.some((key) => !Array.isArray(rawData[key]))) {
    throw new Error('INVALID_BACKUP');
  }
  const data = rawData as Record<(typeof arrayKeys)[number], unknown[]>;
  const entityLists = arrayKeys.map((key) => data[key]);
  if (entityLists.some((rows) => rows.some((row) => !hasString(row, 'id')))) {
    throw new Error('INVALID_BACKUP');
  }
  if (data.contacts.some((row) => !hasString(row, 'fullName'))) throw new Error('INVALID_BACKUP');
  const contactIds = new Set(data.contacts.map((row) => (row as { id: string }).id));
  for (const key of ['phones', 'emails', 'multiValues', 'contactCustomFieldValues'] as const) {
    if (data[key].some((row) => !hasString(row, 'contactId') || !contactIds.has((row as { contactId: string }).contactId))) {
      throw new Error('INVALID_BACKUP');
    }
  }
  const templateIds = new Set(data.customFieldTemplates.map((row) => (row as { id: string }).id));
  if (data.contactCustomFieldValues.some((row) => {
    const templateId = (row as { templateId?: unknown }).templateId;
    return templateId !== null && templateId !== undefined &&
      (typeof templateId !== 'string' || !templateIds.has(templateId));
  })) throw new Error('INVALID_BACKUP');
  return parsed as SmartContactsBackup;
}

export async function createBackup(database: SQLiteDatabase): Promise<SmartContactsBackup> {
  const [contacts, phones, emails, multiValues, customFieldTemplates, contactCustomFieldValues, userProfiles] =
    await Promise.all([
      database.getAllAsync<Contact>('SELECT * FROM Contact ORDER BY createdAt, id'),
      database.getAllAsync<ContactPhone>('SELECT * FROM ContactPhone ORDER BY contactId, isPrimary DESC, id'),
      database.getAllAsync<ContactEmail>('SELECT * FROM ContactEmail ORDER BY contactId, isPrimary DESC, id'),
      database.getAllAsync<ContactMultiValue>('SELECT * FROM ContactMultiValue ORDER BY contactId, position, id'),
      database.getAllAsync<CustomFieldTemplate>('SELECT * FROM CustomFieldTemplate ORDER BY position, id'),
      database.getAllAsync<ContactCustomFieldValue>('SELECT * FROM ContactCustomFieldValue ORDER BY contactId, position, id'),
      database.getAllAsync<UserProfile>('SELECT * FROM UserProfile ORDER BY createdAt, id'),
    ]);
  return {
    schema: BACKUP_SCHEMA,
    version: BACKUP_VERSION,
    exportedAt: new Date().toISOString(),
    app: { name: 'Smart Contacts', version: '1.0.0', direction: 'offline-to-online-compatible' },
    data: { contacts, phones, emails, multiValues, customFieldTemplates, contactCustomFieldValues, userProfiles },
  };
}

async function insertRows(
  database: SQLiteDatabase,
  table: string,
  columns: readonly string[],
  rows: unknown[],
): Promise<void> {
  const placeholders = columns.map(() => '?').join(', ');
  const sql = `INSERT OR IGNORE INTO ${table} (${columns.join(', ')}) VALUES (${placeholders})`;
  for (const row of rows as Record<string, unknown>[]) {
    await database.runAsync(sql, ...columns.map((column) => row[column] as string | number | null));
  }
}

export async function restoreBackup(
  database: SQLiteDatabase,
  backup: SmartContactsBackup,
  mode: RestoreMode,
): Promise<BackupCounts> {
  await database.withTransactionAsync(async () => {
    if (mode === 'overwrite') {
      await database.execAsync(`
        DELETE FROM ContactCustomFieldValue;
        DELETE FROM ContactMultiValue;
        DELETE FROM ContactPhone;
        DELETE FROM ContactEmail;
        DELETE FROM Contact;
        DELETE FROM CustomFieldTemplate;
        DELETE FROM UserProfile;
      `);
    }
    const data = backup.data;
    await insertRows(database, 'CustomFieldTemplate', ['id', 'fieldKey', 'label', 'valueType', 'position', 'isActive', 'createdAt', 'updatedAt'], data.customFieldTemplates);
    await insertRows(database, 'Contact', ['id', 'fullName', 'company', 'title', 'meetingContext', 'linkedinUrl', 'photoUri', 'notes', 'createdAt', 'updatedAt'], data.contacts);
    await insertRows(database, 'ContactPhone', ['id', 'contactId', 'value', 'label', 'isPrimary', 'createdAt', 'updatedAt'], data.phones);
    await insertRows(database, 'ContactEmail', ['id', 'contactId', 'value', 'label', 'isPrimary', 'createdAt', 'updatedAt'], data.emails);
    await insertRows(database, 'ContactMultiValue', ['id', 'contactId', 'fieldKey', 'value', 'position', 'createdAt', 'updatedAt'], data.multiValues);
    await insertRows(database, 'ContactCustomFieldValue', ['id', 'contactId', 'templateId', 'fieldKey', 'fieldLabel', 'value', 'valueType', 'position', 'createdAt', 'updatedAt'], data.contactCustomFieldValues);
    await insertRows(database, 'UserProfile', ['id', 'fullName', 'company', 'title', 'phone', 'email', 'linkedinUrl', 'photoUri', 'notes', 'createdAt', 'updatedAt'], data.userProfiles);
  });
  return {
    contacts: backup.data.contacts.length,
    templates: backup.data.customFieldTemplates.length,
    profiles: backup.data.userProfiles.length,
  };
}
