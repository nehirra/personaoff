import { useCallback, useRef, useState } from 'react';
import { useSQLiteContext } from 'expo-sqlite';

import type { CustomFieldTemplate } from '../../../types/models';
import { getActiveCustomFieldTemplates } from '../data/templateRepository';

export function useCustomFieldTemplates() {
  const database = useSQLiteContext();
  const requestId = useRef(0);
  const [templates, setTemplates] = useState<CustomFieldTemplate[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const reload = useCallback(async () => {
    const activeRequest = ++requestId.current;
    setLoading(true);
    setError(null);
    try {
      const result = await getActiveCustomFieldTemplates(database);
      if (activeRequest === requestId.current) setTemplates(result);
    } catch (cause) {
      if (activeRequest === requestId.current) {
        setError(cause instanceof Error ? cause : new Error(String(cause)));
      }
    } finally {
      if (activeRequest === requestId.current) setLoading(false);
    }
  }, [database]);

  return { error, loading, reload, templates };
}
