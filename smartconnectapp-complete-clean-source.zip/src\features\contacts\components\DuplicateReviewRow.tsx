import { memo } from 'react';
import { StyleSheet, Text, View } from 'react-native';

import { colors, radius, spacing, typography } from '../../../app/theme';
import { Chip, Divider, SectionTitle } from '../../../components';
import { useI18n } from '../../../i18n';
import type {
  DuplicateImportItem,
  ImportDecision,
  MergeValueChoice,
} from '../data/importRepository';

type DuplicateReviewRowProps = {
  decision?: ImportDecision;
  item: DuplicateImportItem;
  onChange: (itemId: string, decision: ImportDecision) => void;
};

function valueSummary(values: Array<{ value: string }>): string {
  return values.map((item) => item.value).join(', ');
}

function ChoiceRow({
  choice,
  existing,
  imported,
  onSelect,
  title,
}: {
  choice?: MergeValueChoice;
  existing: string;
  imported: string;
  onSelect: (choice: MergeValueChoice) => void;
  title: string;
}) {
  const { t } = useI18n();
  return (
    <View style={styles.conflict}>
      <SectionTitle caption={t('importReview.conflictDescription')} title={title} />
      <Text style={styles.valueText}>{t('importReview.existing')}: {existing}</Text>
      <Text style={styles.valueText}>{t('importReview.imported')}: {imported}</Text>
      <View style={styles.chips}>
        <Chip label={t('importReview.keepExisting')} onPress={() => onSelect('existing')} selected={choice === 'existing'} />
        <Chip label={t('importReview.keepImported')} onPress={() => onSelect('imported')} selected={choice === 'imported'} />
        <Chip label={t('importReview.keepBoth')} onPress={() => onSelect('both')} selected={choice === 'both'} />
      </View>
    </View>
  );
}

function DuplicateReviewRowComponent({ decision, item, onChange }: DuplicateReviewRowProps) {
  const { t } = useI18n();
  const action = decision?.action;

  return (
    <View style={styles.card}>
      <Text numberOfLines={2} style={styles.importedName}>{item.imported.fullName}</Text>
      <Text style={styles.matchLabel}>{t('importReview.matches')}</Text>
      <Text numberOfLines={2} style={styles.existingName}>{item.existing.fullName}</Text>
      <View style={styles.chips}>
        <Chip
          label={t('importReview.merge')}
          onPress={() => onChange(item.id, { ...decision, action: 'merge' })}
          selected={action === 'merge'}
        />
        <Chip
          label={t('importReview.separate')}
          onPress={() => onChange(item.id, { ...decision, action: 'separate' })}
          selected={action === 'separate'}
        />
      </View>

      {action === 'merge' && (item.phoneConflict || item.emailConflict) ? <Divider /> : null}
      {action === 'merge' && item.phoneConflict ? (
        <ChoiceRow
          choice={decision?.phoneChoice}
          existing={valueSummary(item.existing.phones)}
          imported={valueSummary(item.imported.phones)}
          onSelect={(phoneChoice) => onChange(item.id, { ...decision, action: 'merge', phoneChoice })}
          title={t('form.phone')}
        />
      ) : null}
      {action === 'merge' && item.phoneConflict && item.emailConflict ? <Divider /> : null}
      {action === 'merge' && item.emailConflict ? (
        <ChoiceRow
          choice={decision?.emailChoice}
          existing={valueSummary(item.existing.emails)}
          imported={valueSummary(item.imported.emails)}
          onSelect={(emailChoice) => onChange(item.id, { ...decision, action: 'merge', emailChoice })}
          title={t('form.email')}
        />
      ) : null}
    </View>
  );
}

export const DuplicateReviewRow = memo(DuplicateReviewRowComponent);

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.surface,
    borderColor: colors.border,
    borderRadius: radius.lg,
    borderWidth: 1,
    padding: spacing.lg,
  },
  importedName: { color: colors.text, fontSize: typography.section, fontWeight: '800' },
  matchLabel: { color: colors.textMuted, fontSize: typography.caption, marginTop: spacing.md },
  existingName: { color: colors.primary, fontSize: typography.body, fontWeight: '700', marginTop: spacing.xs },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm, marginTop: spacing.md },
  conflict: { gap: spacing.sm },
  valueText: { color: colors.textMuted, fontSize: typography.caption, lineHeight: 19 },
});
