import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { useState } from 'react';
import { Alert, StyleSheet, Text, View } from 'react-native';
import { useSQLiteContext } from 'expo-sqlite';

import { colors, radius, spacing, typography } from '../../../app/theme';
import { AppHeader, AppScreen, IconButton, PrimaryButton, SectionTitle } from '../../../components';
import { useI18n } from '../../../i18n';
import type { ProfileStackParamList } from '../../../types/navigation';
import { createBackup, restoreBackup, type RestoreMode, type SmartContactsBackup } from '../data/backupRepository';
import { exportBackupFile, pickBackupFile } from '../services/backupFileService';

type Props = NativeStackScreenProps<ProfileStackParamList, 'Backup'>;

export function BackupScreen({ navigation }: Props) {
  const database = useSQLiteContext();
  const { t } = useI18n();
  const [busy, setBusy] = useState<'export' | 'import' | null>(null);

  const exportData = async () => {
    setBusy('export');
    try { await exportBackupFile(await createBackup(database)); }
    catch { Alert.alert(t('backup.exportError.title'), t('backup.exportError.description')); }
    finally { setBusy(null); }
  };

  const applyImport = async (backup: SmartContactsBackup, mode: RestoreMode) => {
    setBusy('import');
    try {
      const counts = await restoreBackup(database, backup, mode);
      Alert.alert(t('backup.success.title'), `${t('backup.success.contacts')}: ${counts.contacts} • ${t('backup.success.templates')}: ${counts.templates}`);
    } catch { Alert.alert(t('backup.importError.title'), t('backup.importError.description')); }
    finally { setBusy(null); }
  };

  const importData = async () => {
    setBusy('import');
    try {
      const backup = await pickBackupFile();
      setBusy(null);
      if (!backup) return;
      Alert.alert(t('backup.mode.title'), t('backup.mode.description'), [
        { style: 'cancel', text: t('buttons.cancel') },
        { text: t('backup.mode.merge'), onPress: () => void applyImport(backup, 'merge') },
        { style: 'destructive', text: t('backup.mode.overwrite'), onPress: () => void applyImport(backup, 'overwrite') },
      ]);
    } catch (error) {
      setBusy(null);
      const invalid = error instanceof Error && ['INVALID_JSON', 'INVALID_BACKUP', 'UNSUPPORTED_BACKUP'].includes(error.message);
      Alert.alert(invalid ? t('backup.invalid.title') : t('backup.importError.title'), invalid ? t('backup.invalid.description') : t('backup.importError.description'));
    }
  };

  return (
    <AppScreen scrollable>
      <AppHeader leading={<IconButton accessibilityLabel={t('backup.back')} icon="arrow-back" onPress={navigation.goBack} />} subtitle={t('backup.subtitle')} title={t('backup.title')} />
      <SectionTitle caption={t('backup.export.description')} title={t('backup.export.title')} />
      <View style={styles.card}>
        <Text style={styles.copy}>{t('backup.contents')}</Text>
        <PrimaryButton label={t('backup.export.action')} loading={busy === 'export'} onPress={() => void exportData()} />
      </View>
      <View style={styles.section}>
        <SectionTitle caption={t('backup.import.description')} title={t('backup.import.title')} />
        <View style={styles.card}>
          <Text style={styles.warning}>{t('backup.import.warning')}</Text>
          <PrimaryButton label={t('backup.import.action')} loading={busy === 'import'} onPress={() => void importData()} />
        </View>
      </View>
    </AppScreen>
  );
}

const styles = StyleSheet.create({
  card: { backgroundColor: colors.surface, borderColor: colors.border, borderRadius: radius.lg, borderWidth: 1, gap: spacing.lg, marginTop: spacing.lg, padding: spacing.lg },
  section: { marginTop: spacing.xxl },
  copy: { color: colors.textMuted, fontSize: typography.body, lineHeight: 23 },
  warning: { color: colors.text, fontSize: typography.body, lineHeight: 23 },
});
