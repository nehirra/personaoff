import { useFocusEffect } from '@react-navigation/native';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { useCallback, useState } from 'react';
import { ActivityIndicator, Alert, StyleSheet, Text, View } from 'react-native';
import { useSQLiteContext } from 'expo-sqlite';

import { colors, radius, spacing, typography } from '../../../app/theme';
import {
  AppHeader,
  AppScreen,
  Chip,
  Divider,
  IconButton,
  PrimaryButton,
  SectionTitle,
  TextInputField,
} from '../../../components';
import { useI18n } from '../../../i18n';
import type { ProfileStackParamList } from '../../../types/navigation';
import {
  applyTemplateToExistingContacts,
  createCustomFieldTemplate,
  deactivateCustomFieldTemplate,
} from '../data/templateRepository';
import { useCustomFieldTemplates } from '../hooks/useCustomFieldTemplates';
import { useUserProfile } from '../hooks/useUserProfile';

type ProfileScreenProps = NativeStackScreenProps<ProfileStackParamList, 'ProfileHome'>;

export function ProfileScreen({ navigation }: ProfileScreenProps) {
  const { locale, setLocale, t } = useI18n();
  const database = useSQLiteContext();
  const { error, loading, reload, templates } = useCustomFieldTemplates();
  const {
    error: profileError,
    loading: profileLoading,
    profile,
    reload: reloadProfile,
  } = useUserProfile();
  const [templateName, setTemplateName] = useState('');
  const [templateError, setTemplateError] = useState<string | undefined>();
  const [savingTemplate, setSavingTemplate] = useState(false);

  useFocusEffect(useCallback(() => {
    void reload();
    void reloadProfile();
  }, [reload, reloadProfile]));

  const addTemplate = async () => {
    if (!templateName.trim()) {
      setTemplateError(t('errors.required'));
      return;
    }

    setSavingTemplate(true);
    setTemplateError(undefined);
    try {
      const templateId = await createCustomFieldTemplate(database, templateName);
      setTemplateName('');
      Alert.alert(t('templates.apply.title'), t('templates.apply.description'), [
        {
          text: t('buttons.no'),
          onPress: () => { void reload(); },
        },
        {
          text: t('buttons.yes'),
          onPress: () => {
            void applyTemplateToExistingContacts(database, templateId)
              .then(reload)
              .catch(() => Alert.alert(t('templates.applyError'), t('errors.generic')));
          },
        },
      ], { cancelable: false });
    } catch {
      setTemplateError(t('templates.saveError'));
    } finally {
      setSavingTemplate(false);
    }
  };

  const confirmDelete = (templateId: string) => {
    Alert.alert(t('templates.delete.title'), t('templates.delete.description'), [
      { style: 'cancel', text: t('buttons.cancel') },
      {
        style: 'destructive',
        text: t('buttons.delete'),
        onPress: () => {
          void deactivateCustomFieldTemplate(database, templateId)
            .then(reload)
            .catch(() => Alert.alert(t('templates.deleteError'), t('errors.generic')));
        },
      },
    ]);
  };

  return (
    <AppScreen scrollable>
      <AppHeader
        action={
          <IconButton
            accessibilityLabel={profile ? t('userProfile.editTitle') : t('userProfile.createTitle')}
            icon={profile ? 'create-outline' : 'person-add-outline'}
            onPress={() => navigation.navigate('EditUserProfile')}
          />
        }
        subtitle={t('profile.subtitle')}
        title={t('profile.title')}
      />

      <SectionTitle caption={t('userProfile.description')} title={t('userProfile.title')} />
      <View style={styles.card}>
        {profileLoading ? <ActivityIndicator color={colors.primary} /> : null}
        {profileError ? <Text style={styles.errorText}>{t('userProfile.loadError')}</Text> : null}
        {!profileLoading && !profileError && !profile ? (
          <View style={styles.profileEmpty}>
            <Text style={styles.emptyText}>{t('userProfile.empty')}</Text>
            <PrimaryButton
              label={t('userProfile.createTitle')}
              onPress={() => navigation.navigate('EditUserProfile')}
            />
          </View>
        ) : null}
        {profile ? (
          <View>
            <Text numberOfLines={2} style={styles.profileName}>{profile.fullName}</Text>
            {[profile.company, profile.title].filter(Boolean).length > 0 ? (
              <Text numberOfLines={2} style={styles.profileProfessional}>
                {[profile.company, profile.title].filter(Boolean).join(' • ')}
              </Text>
            ) : null}
            {profile.phone ? <Text selectable style={styles.profileDetail}>{profile.phone}</Text> : null}
            {profile.email ? <Text selectable style={styles.profileDetail}>{profile.email}</Text> : null}
            {profile.linkedinUrl ? <Text selectable style={styles.profileDetail}>{profile.linkedinUrl}</Text> : null}
            {profile.notes ? <Text style={styles.profileBio}>{profile.notes}</Text> : null}
            <View style={styles.profileAction}>
              <PrimaryButton
                label={t('userProfile.editTitle')}
                onPress={() => navigation.navigate('EditUserProfile')}
              />
            </View>
          </View>
        ) : null}
      </View>

      <View style={styles.settingsSection}>
      <SectionTitle title={t('profile.settings.title')} />
      <View style={styles.card}>
        <SectionTitle caption={t('profile.language.description')} title={t('profile.language.title')} />
        <Divider />
        <View style={styles.languageRow}>
          <Chip label={t('profile.language.turkish')} onPress={() => setLocale('tr')} selected={locale === 'tr'} />
          <Chip label={t('profile.language.english')} onPress={() => setLocale('en')} selected={locale === 'en'} />
        </View>
      </View>
      </View>

      <View style={styles.settingsSection}>
        <SectionTitle caption={t('backup.profileDescription')} title={t('backup.title')} />
        <View style={styles.card}>
          <PrimaryButton label={t('backup.manage')} onPress={() => navigation.navigate('Backup')} />
        </View>
      </View>

      <View style={styles.templateSection}>
        <SectionTitle caption={t('templates.description')} title={t('templates.title')} />
        <View style={styles.card}>
          <TextInputField
            autoCapitalize="sentences"
            error={templateError}
            label={t('templates.name')}
            onChangeText={(value) => {
              setTemplateName(value);
              setTemplateError(undefined);
            }}
            placeholder={t('templates.placeholder')}
            value={templateName}
          />
          <View style={styles.addTemplateButton}>
            <PrimaryButton
              label={t('templates.add')}
              loading={savingTemplate}
              onPress={() => void addTemplate()}
            />
          </View>
          <Divider />
          {loading ? <ActivityIndicator color={colors.primary} /> : null}
          {error ? <Text style={styles.errorText}>{t('templates.loadError')}</Text> : null}
          {!loading && !error && templates.length === 0 ? (
            <Text style={styles.emptyText}>{t('templates.empty')}</Text>
          ) : null}
          {templates.map((template, index) => (
            <View key={template.id}>
              {index > 0 ? <Divider compact /> : null}
              <View style={styles.templateRow}>
                <View style={styles.templateCopy}>
                  <Text numberOfLines={2} style={styles.templateLabel}>{template.label}</Text>
                  <Text style={styles.templateType}>{t('templates.textType')}</Text>
                </View>
                <IconButton
                  accessibilityLabel={t('templates.deleteAction')}
                  icon="trash-outline"
                  onPress={() => confirmDelete(template.id)}
                />
              </View>
            </View>
          ))}
        </View>
      </View>
    </AppScreen>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.surface,
    borderColor: colors.border,
    borderRadius: radius.lg,
    borderWidth: 1,
    marginTop: spacing.lg,
    padding: spacing.lg,
  },
  languageRow: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm },
  settingsSection: { marginTop: spacing.xxl },
  profileEmpty: { gap: spacing.lg },
  profileName: { color: colors.text, fontSize: 22, fontWeight: '800' },
  profileProfessional: { color: colors.textMuted, fontSize: typography.body, marginTop: spacing.xs },
  profileDetail: { color: colors.text, fontSize: typography.caption, marginTop: spacing.sm },
  profileBio: { color: colors.textMuted, fontSize: typography.body, lineHeight: 23, marginTop: spacing.lg },
  profileAction: { marginTop: spacing.lg },
  templateSection: { marginTop: spacing.xxl },
  addTemplateButton: { marginTop: spacing.lg },
  templateRow: { alignItems: 'center', flexDirection: 'row', gap: spacing.md, paddingVertical: spacing.md },
  templateCopy: { flex: 1, minWidth: 0 },
  templateLabel: { color: colors.text, fontSize: typography.body, fontWeight: '700' },
  templateType: { color: colors.textMuted, fontSize: typography.caption, marginTop: spacing.xs },
  emptyText: { color: colors.textMuted, fontSize: typography.body, lineHeight: 23, textAlign: 'center' },
  errorText: { color: colors.danger, fontSize: typography.caption, textAlign: 'center' },
});
