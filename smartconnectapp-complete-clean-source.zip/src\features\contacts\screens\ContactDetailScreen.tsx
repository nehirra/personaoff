import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { useCallback } from 'react';
import { ActivityIndicator, Alert, StyleSheet, Text, View } from 'react-native';
import { useSQLiteContext } from 'expo-sqlite';

import { colors, radius, spacing, typography } from '../../../app/theme';
import { AppHeader, AppScreen, Chip, Divider, EmptyState, IconButton, SectionTitle } from '../../../components';
import { useI18n } from '../../../i18n';
import type { ContactsStackParamList } from '../../../types/navigation';
import { deleteContact } from '../data/contactRepository';
import { useContactDetail } from '../hooks/useContactDetail';

type ContactDetailScreenProps = NativeStackScreenProps<ContactsStackParamList, 'ContactDetail'>;

type DetailFieldProps = {
  icon?: keyof typeof Ionicons.glyphMap;
  label: string;
  primary?: boolean;
  primaryLabel?: string;
  value: string;
};

function DetailField({ icon, label, primary, primaryLabel, value }: DetailFieldProps) {
  return (
    <View style={styles.field}>
      {icon ? <Ionicons color={colors.primary} name={icon} size={20} /> : null}
      <View style={styles.fieldCopy}>
        <View style={styles.fieldLabelRow}>
          <Text numberOfLines={1} style={styles.fieldLabel}>{label}</Text>
          {primary && primaryLabel ? <Chip label={primaryLabel} /> : null}
        </View>
        <Text selectable style={styles.fieldValue}>{value}</Text>
      </View>
    </View>
  );
}

function DetailSection({ children, title }: { children: React.ReactNode; title: string }) {
  return (
    <View style={styles.section}>
      <SectionTitle title={title} />
      <View style={styles.card}>{children}</View>
    </View>
  );
}

function hasText(value: string | null): value is string {
  return Boolean(value?.trim());
}

export function ContactDetailScreen({ navigation, route }: ContactDetailScreenProps) {
  const { t } = useI18n();
  const database = useSQLiteContext();
  const { contact, error, loading, reload } = useContactDetail(route.params.contactId);

  useFocusEffect(
    useCallback(() => {
      void reload();
    }, [reload]),
  );

  const confirmDelete = () => {
    Alert.alert(t('detail.deleteConfirm.title'), t('detail.deleteConfirm.description'), [
      { style: 'cancel', text: t('buttons.cancel') },
      {
        style: 'destructive',
        text: t('buttons.delete'),
        onPress: () => {
          void deleteContact(database, route.params.contactId)
            .then(() => navigation.goBack())
            .catch(() => Alert.alert(t('detail.deleteError.title'), t('detail.deleteError.description')));
        },
      },
    ]);
  };

  if (loading && !contact) {
    return (
      <AppScreen>
        <View style={styles.centered}>
          <ActivityIndicator color={colors.primary} size="large" />
          <Text style={styles.loadingText}>{t('detail.loading')}</Text>
        </View>
      </AppScreen>
    );
  }

  if (error || !contact) {
    return (
      <AppScreen>
        <AppHeader
          leading={<IconButton accessibilityLabel={t('detail.back')} icon="arrow-back" onPress={navigation.goBack} />}
          title={t('detail.notFound.title')}
        />
        <EmptyState
          actionLabel={error ? t('buttons.retry') : undefined}
          description={error ? t('contacts.error.description') : t('detail.notFound.description')}
          icon="person-remove-outline"
          onAction={error ? () => void reload() : undefined}
          title={error ? t('contacts.error.title') : t('detail.notFound.title')}
        />
      </AppScreen>
    );
  }

  const professionalSummary = [contact.company, contact.title].filter(hasText).join(' • ');
  const hasProfessionalDetails = hasText(contact.company) || hasText(contact.title);
  const visibleCustomFields = contact.customFields.filter((field) => field.value.trim());

  return (
    <AppScreen scrollable>
      <AppHeader
        action={
          <View style={styles.actions}>
            <IconButton
              accessibilityLabel={t('detail.edit')}
              icon="create-outline"
              onPress={() => navigation.navigate('EditContact', { contactId: contact.id })}
            />
            <IconButton accessibilityLabel={t('detail.delete')} icon="trash-outline" onPress={confirmDelete} />
          </View>
        }
        leading={<IconButton accessibilityLabel={t('detail.back')} icon="arrow-back" onPress={navigation.goBack} />}
        subtitle={professionalSummary || undefined}
        title={contact.fullName}
      />

      {contact.phones.length > 0 || contact.emails.length > 0 ? (
        <DetailSection title={t('detail.contactInfo')}>
          {contact.phones.map((phone, index) => (
            <View key={phone.id}>
              {index > 0 ? <Divider compact /> : null}
              <DetailField
                icon="call-outline"
                label={phone.label || t('form.phone')}
                primary={phone.isPrimary === 1}
                primaryLabel={t('detail.primary')}
                value={phone.value}
              />
            </View>
          ))}
          {contact.emails.map((email, index) => (
            <View key={email.id}>
              {contact.phones.length > 0 || index > 0 ? <Divider compact /> : null}
              <DetailField
                icon="mail-outline"
                label={email.label || t('form.email')}
                primary={email.isPrimary === 1}
                primaryLabel={t('detail.primary')}
                value={email.value}
              />
            </View>
          ))}
        </DetailSection>
      ) : null}

      {hasProfessionalDetails ? (
        <DetailSection title={t('detail.professional')}>
          {hasText(contact.company) ? <DetailField icon="business-outline" label={t('form.company')} value={contact.company} /> : null}
          {hasText(contact.company) && hasText(contact.title) ? <Divider compact /> : null}
          {hasText(contact.title) ? <DetailField icon="briefcase-outline" label={t('form.title')} value={contact.title} /> : null}
        </DetailSection>
      ) : null}

      {hasText(contact.meetingContext) ? (
        <DetailSection title={t('detail.meetingContext')}>
          <DetailField icon="location-outline" label={t('form.meetingContext')} value={contact.meetingContext} />
        </DetailSection>
      ) : null}

      {hasText(contact.linkedinUrl) ? (
        <DetailSection title={t('detail.social')}>
          <DetailField icon="link-outline" label={t('form.linkedinUrl')} value={contact.linkedinUrl} />
        </DetailSection>
      ) : null}

      {contact.multiValues.length > 0 ? (
        <DetailSection title={t('detail.multiValues')}>
          {contact.multiValues.map((group, index) => (
            <View key={group.fieldKey}>
              {index > 0 ? <Divider compact /> : null}
              <View style={styles.multiGroup}>
                <Text style={styles.fieldLabel}>{group.fieldKey}</Text>
                <View style={styles.chips}>
                  {group.items.map((item) => <Chip key={item.id} label={item.value} />)}
                </View>
              </View>
            </View>
          ))}
        </DetailSection>
      ) : null}

      {visibleCustomFields.length > 0 ? (
        <DetailSection title={t('detail.customFields')}>
          {visibleCustomFields.map((field, index) => (
            <View key={field.id}>
              {index > 0 ? <Divider compact /> : null}
              <DetailField label={field.fieldLabel} value={field.value} />
            </View>
          ))}
        </DetailSection>
      ) : null}

      {hasText(contact.notes) ? (
        <DetailSection title={t('detail.notes')}>
          <DetailField icon="document-text-outline" label={t('form.notes')} value={contact.notes} />
        </DetailSection>
      ) : null}
    </AppScreen>
  );
}

const styles = StyleSheet.create({
  centered: { alignItems: 'center', flex: 1, gap: spacing.md, justifyContent: 'center' },
  loadingText: { color: colors.textMuted, fontSize: typography.body },
  actions: { flexDirection: 'row', gap: spacing.sm },
  section: { gap: spacing.md, marginBottom: spacing.xl },
  card: {
    backgroundColor: colors.surface,
    borderColor: colors.border,
    borderRadius: radius.lg,
    borderWidth: 1,
    paddingHorizontal: spacing.lg,
  },
  field: { alignItems: 'flex-start', flexDirection: 'row', gap: spacing.md, paddingVertical: spacing.lg },
  fieldCopy: { flex: 1, minWidth: 0 },
  fieldLabelRow: { alignItems: 'center', flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm },
  fieldLabel: { color: colors.textMuted, flexShrink: 1, fontSize: typography.caption, fontWeight: '700' },
  fieldValue: { color: colors.text, fontSize: typography.body, lineHeight: 23, marginTop: spacing.xs },
  multiGroup: { gap: spacing.sm, paddingVertical: spacing.lg },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm },
});
