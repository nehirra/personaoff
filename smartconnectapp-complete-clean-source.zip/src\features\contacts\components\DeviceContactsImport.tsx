import { useEffect, useState } from 'react';
import { ActivityIndicator, StyleSheet, Text, View } from 'react-native';

import { colors, radius, spacing, typography } from '../../../app/theme';
import { EmptyState, PrimaryButton, SectionTitle } from '../../../components';
import { useI18n } from '../../../i18n';
import {
  requestAndReadDeviceContacts,
  type ImportedDeviceContact,
} from '../services/deviceContactsService';

type ImportState =
  | { status: 'loading' }
  | { status: 'denied' }
  | { status: 'error' }
  | { status: 'ready'; contacts: ImportedDeviceContact[] };

type DeviceContactsImportProps = {
  onChooseManual: () => void;
  onReview: (contacts: ImportedDeviceContact[]) => void;
};

export function DeviceContactsImport({ onChooseManual, onReview }: DeviceContactsImportProps) {
  const { t } = useI18n();
  const [state, setState] = useState<ImportState>({ status: 'loading' });

  const loadContacts = async () => {
    setState({ status: 'loading' });
    try {
      const result = await requestAndReadDeviceContacts();
      setState(
        result.status === 'denied'
          ? { status: 'denied' }
          : { status: 'ready', contacts: result.contacts },
      );
    } catch {
      setState({ status: 'error' });
    }
  };

  useEffect(() => { void loadContacts(); }, []);

  if (state.status === 'loading') {
    return (
      <View style={styles.status}>
        <ActivityIndicator color={colors.primary} size="large" />
        <Text style={styles.statusText}>{t('deviceImport.reading')}</Text>
      </View>
    );
  }

  if (state.status === 'denied') {
    return (
      <EmptyState
        actionLabel={t('deviceImport.useManual')}
        description={t('deviceImport.denied.description')}
        icon="lock-closed-outline"
        onAction={onChooseManual}
        title={t('deviceImport.denied.title')}
      />
    );
  }

  if (state.status === 'error') {
    return (
      <EmptyState
        actionLabel={t('buttons.retry')}
        description={t('deviceImport.error.description')}
        icon="alert-circle-outline"
        onAction={() => void loadContacts()}
        title={t('deviceImport.error.title')}
      />
    );
  }

  if (state.contacts.length === 0) {
    return (
      <EmptyState
        actionLabel={t('deviceImport.useManual')}
        description={t('deviceImport.empty.description')}
        icon="phone-portrait-outline"
        onAction={onChooseManual}
        title={t('deviceImport.empty.title')}
      />
    );
  }

  return (
    <View style={styles.container}>
      <SectionTitle
        caption={t('deviceImport.ready.description')}
        title={`${state.contacts.length} ${t('deviceImport.ready.title')}`}
      />
      <View style={styles.previewCard}>
        {state.contacts.slice(0, 10).map((contact) => (
          <View key={contact.sourceId} style={styles.previewRow}>
            <Text numberOfLines={1} style={styles.name}>{contact.fullName}</Text>
            <Text numberOfLines={1} style={styles.detail}>
              {contact.phones[0]?.value ?? contact.emails[0]?.value ?? t('deviceImport.noContactInfo')}
            </Text>
          </View>
        ))}
        {state.contacts.length > 10 ? (
          <Text style={styles.moreText}>{t('deviceImport.more')}</Text>
        ) : null}
      </View>
      <PrimaryButton
        label={t('deviceImport.review')}
        onPress={() => onReview(state.contacts)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { gap: spacing.lg },
  status: { alignItems: 'center', gap: spacing.md, paddingVertical: spacing.xxl },
  statusText: { color: colors.textMuted, fontSize: typography.body },
  previewCard: {
    backgroundColor: colors.surface,
    borderColor: colors.border,
    borderRadius: radius.lg,
    borderWidth: 1,
    paddingHorizontal: spacing.lg,
  },
  previewRow: { borderBottomColor: colors.border, borderBottomWidth: StyleSheet.hairlineWidth, paddingVertical: spacing.md },
  name: { color: colors.text, fontSize: typography.body, fontWeight: '700' },
  detail: { color: colors.textMuted, fontSize: typography.caption, marginTop: spacing.xs },
  moreText: { color: colors.primary, fontSize: typography.caption, fontWeight: '700', paddingVertical: spacing.md, textAlign: 'center' },
});
