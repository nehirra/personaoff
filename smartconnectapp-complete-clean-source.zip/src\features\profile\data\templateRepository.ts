import type { SQLiteDatabase } from 'expo-sqlite';

import type { CustomFieldTemplate } from '../../../types/models';
import { createId } from '../../../utils/createId';

export async function getActiveCustomFieldTemplates(
  database: SQLiteDatabase,
): Promise<CustomFieldTemplate[]> {
  return database.getAllAsync<CustomFieldTemplate>(
    `SELECT id, fieldKey, label, valueType, position, isActive, createdAt, updatedAt
     FROM CustomFieldTemplate
     WHERE isActive = 1
     ORDER BY position ASC, createdAt ASC`,
  );
}

export async function createCustomFieldTemplate(
  database: SQLiteDatabase,
  label: string,
): Promise<string> {
  const normalizedLabel = label.trim();
  if (!normalizedLabel) throw new Error('Template label is required');

  const id = createId('template');
  const fieldKey = createId('field');
  const timestamp = new Date().toISOString();

  await database.withTransactionAsync(async () => {
    const positionRow = await database.getFirstAsync<{ nextPosition: number }>(
      'SELECT COALESCE(MAX(position), -1) + 1 AS nextPosition FROM CustomFieldTemplate',
    );
    await database.runAsync(
      `INSERT INTO CustomFieldTemplate
       (id, fieldKey, label, valueType, position, isActive, createdAt, updatedAt)
       VALUES (?, ?, ?, 'text', ?, 1, ?, ?)`,
      id,
      fieldKey,
      normalizedLabel,
      positionRow?.nextPosition ?? 0,
      timestamp,
      timestamp,
    );
  });

  return id;
}

export async function deactivateCustomFieldTemplate(
  database: SQLiteDatabase,
  templateId: string,
): Promise<void> {
  const result = await database.runAsync(
    'UPDATE CustomFieldTemplate SET isActive = 0, updatedAt = ? WHERE id = ? AND isActive = 1',
    new Date().toISOString(),
    templateId,
  );
  if (result.changes !== 1) throw new Error('Template not found');
}

export async function applyTemplateToExistingContacts(
  database: SQLiteDatabase,
  templateId: string,
): Promise<void> {
  const template = await database.getFirstAsync<CustomFieldTemplate>(
    `SELECT id, fieldKey, label, valueType, position, isActive, createdAt, updatedAt
     FROM CustomFieldTemplate WHERE id = ? AND isActive = 1`,
    templateId,
  );
  if (!template) throw new Error('Template not found');

  const timestamp = new Date().toISOString();
  await database.withTransactionAsync(async () => {
    await database.runAsync(
      `INSERT OR IGNORE INTO ContactCustomFieldValue
       (id, contactId, templateId, fieldKey, fieldLabel, value, valueType, position, createdAt, updatedAt)
       SELECT
         'custom_' || lower(hex(randomblob(16))),
         contact.id,
         ?, ?, ?, NULL, ?, ?, ?, ?
       FROM Contact contact`,
      template.id,
      template.fieldKey,
      template.label,
      template.valueType,
      template.position,
      timestamp,
      timestamp,
    );
  });
}
