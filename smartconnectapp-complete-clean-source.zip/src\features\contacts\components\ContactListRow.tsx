import { Ionicons } from '@expo/vector-icons';
import { memo } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';

import { colors, radius, spacing, typography } from '../../../app/theme';
import { Chip } from '../../../components';
import type { ContactListItem } from '../types';

type ContactListRowProps = {
  contact: ContactListItem;
  onPress: () => void;
};

function getInitials(fullName: string): string {
  return fullName
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((part) => part.charAt(0).toLocaleUpperCase())
    .join('');
}

function ContactListRowComponent({ contact, onPress }: ContactListRowProps) {
  const professionalDetails = [contact.company, contact.title].filter(Boolean).join(' • ');
  const contactDetail = contact.phone ?? contact.email;

  return (
    <Pressable
      accessibilityRole="button"
      onPress={onPress}
      style={({ pressed }) => [styles.container, pressed && styles.pressed]}
    >
      <View style={styles.avatar}>
        <Text numberOfLines={1} style={styles.initials}>{getInitials(contact.fullName)}</Text>
      </View>
      <View style={styles.content}>
        <Text numberOfLines={1} style={styles.name}>{contact.fullName}</Text>
        {professionalDetails ? (
          <Text numberOfLines={1} style={styles.secondary}>{professionalDetails}</Text>
        ) : null}
        {contactDetail ? (
          <View style={styles.contactDetail}>
            <Ionicons
              color={colors.textMuted}
              name={contact.phone ? 'call-outline' : 'mail-outline'}
              size={14}
            />
            <Text numberOfLines={1} style={styles.contactDetailText}>{contactDetail}</Text>
          </View>
        ) : null}
        {contact.tags.length > 0 ? (
          <View style={styles.tags}>
            {contact.tags.map((tag) => <Chip key={tag} label={tag} />)}
          </View>
        ) : null}
      </View>
      <Ionicons color={colors.textMuted} name="chevron-forward" size={18} />
    </Pressable>
  );
}

export const ContactListRow = memo(ContactListRowComponent);

const styles = StyleSheet.create({
  container: { alignItems: 'center', flexDirection: 'row', paddingVertical: spacing.lg },
  pressed: { opacity: 0.65 },
  avatar: {
    alignItems: 'center',
    backgroundColor: colors.primarySoft,
    borderRadius: radius.pill,
    height: 48,
    justifyContent: 'center',
    marginRight: spacing.md,
    width: 48,
  },
  initials: { color: colors.primary, fontSize: typography.body, fontWeight: '800', maxWidth: 38 },
  content: { flex: 1, minWidth: 0 },
  name: { color: colors.text, fontSize: typography.body, fontWeight: '700' },
  secondary: { color: colors.textMuted, fontSize: typography.caption, marginTop: spacing.xs },
  contactDetail: { alignItems: 'center', flexDirection: 'row', gap: spacing.xs, marginTop: spacing.sm },
  contactDetailText: { color: colors.textMuted, flex: 1, fontSize: typography.caption },
  tags: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.xs, marginTop: spacing.sm },
});
