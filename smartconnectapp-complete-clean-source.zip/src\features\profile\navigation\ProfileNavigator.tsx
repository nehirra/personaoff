import { createNativeStackNavigator } from '@react-navigation/native-stack';

import type { ProfileStackParamList } from '../../../types/navigation';
import { EditUserProfileScreen } from '../screens/EditUserProfileScreen';
import { ProfileScreen } from '../screens/ProfileScreen';
import { BackupScreen } from '../screens/BackupScreen';

const Stack = createNativeStackNavigator<ProfileStackParamList>();

export function ProfileNavigator() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="ProfileHome" component={ProfileScreen} />
      <Stack.Screen name="EditUserProfile" component={EditUserProfileScreen} />
      <Stack.Screen name="Backup" component={BackupScreen} />
    </Stack.Navigator>
  );
}
