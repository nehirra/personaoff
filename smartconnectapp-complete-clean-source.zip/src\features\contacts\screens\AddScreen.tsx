import type { BottomTabScreenProps } from '@react-navigation/bottom-tabs';
import { useFocusEffect } from '@react-navigation/native';
import { useCallback } from 'react';
import { useState } from 'react';
import { StyleSheet, View } from 'react-native';
import { useSQLiteContext } from 'expo-sqlite';

import { spacing } from '../../../app/theme';
import { AppHeader, AppScreen, Chip, Divider, SectionTitle } from '../../../components';
import { useI18n } from '../../../i18n';
import type { RootTabParamList } from '../../../types/navigation';
import { ContactForm } from '../components/ContactForm';
import { emptyContactForm } from '../components/ContactForm';
import { DeviceContactsImport } from '../components/DeviceContactsImport';
import { createContact, type ContactFormInput } from '../data/contactRepository';
import { useCustomFieldTemplates } from '../../profile/hooks/useCustomFieldTemplates';
import { buildContactFormCustomFields } from '../utils/buildCustomFields';
import { createImportSession } from '../services/importSessionStore';
import type { ImportedDeviceContact } from '../services/deviceContactsService';

type AddScreenProps = BottomTabScreenProps<RootTabParamList, 'Add'>;

export function AddScreen({ navigation }: AddScreenProps) {
  const { t } = useI18n();
  const database = useSQLiteContext();
  const { reload: reloadTemplates, templates } = useCustomFieldTemplates();
  const [mode, setMode] = useState<'manual' | 'device'>('manual');

  useFocusEffect(useCallback(() => { void reloadTemplates(); }, [reloadTemplates]));

  const initialValues: ContactFormInput = {
    ...emptyContactForm,
    customFields: buildContactFormCustomFields(templates),
  };

  const saveContact = async (values: ContactFormInput) => {
    const contactId = await createContact(database, values);
    navigation.navigate('Contacts', { screen: 'ContactDetail', params: { contactId } });
  };

  const reviewImportedContacts = (contacts: ImportedDeviceContact[]) => {
    const sessionId = createImportSession(contacts);
    navigation.navigate('Contacts', { screen: 'ImportReview', params: { sessionId } });
  };

  return (
    <AppScreen scrollable>
      <AppHeader subtitle={t('add.subtitle')} title={t('add.title')} />
      <SectionTitle title={t('add.method.title')} />
      <View style={styles.chipRow}>
        <Chip
          label={t('add.method.manual')}
          onPress={() => setMode('manual')}
          selected={mode === 'manual'}
        />
        <Chip
          label={t('add.method.device')}
          onPress={() => setMode('device')}
          selected={mode === 'device'}
        />
      </View>
      <Divider />
      {mode === 'manual' ? (
        <ContactForm
          key={templates.map((template) => template.id).join(':')}
          initialValues={initialValues}
          onSubmit={saveContact}
          submitLabel={t('buttons.createContact')}
        />
      ) : (
        <DeviceContactsImport
          onChooseManual={() => setMode('manual')}
          onReview={reviewImportedContacts}
        />
      )}
    </AppScreen>
  );
}

const styles = StyleSheet.create({
  chipRow: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm, marginTop: spacing.lg },
});
