import { useFocusEffect } from '@react-navigation/native';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { useCallback } from 'react';
import { ActivityIndicator, StyleSheet, Text, View } from 'react-native';
import { useSQLiteContext } from 'expo-sqlite';

import { colors, spacing, typography } from '../../../app/theme';
import { AppHeader, AppScreen, EmptyState, IconButton } from '../../../components';
import { useI18n } from '../../../i18n';
import type { ContactsStackParamList } from '../../../types/navigation';
import { ContactForm } from '../components/ContactForm';
import { updateContact, type ContactFormInput } from '../data/contactRepository';
import { useContactDetail } from '../hooks/useContactDetail';
import { useCustomFieldTemplates } from '../../profile/hooks/useCustomFieldTemplates';
import { buildContactFormCustomFields } from '../utils/buildCustomFields';

type EditContactScreenProps = NativeStackScreenProps<ContactsStackParamList, 'EditContact'>;

export function EditContactScreen({ navigation, route }: EditContactScreenProps) {
  const { t } = useI18n();
  const database = useSQLiteContext();
  const { contact, error, loading, reload } = useContactDetail(route.params.contactId);
  const { reload: reloadTemplates, templates } = useCustomFieldTemplates();

  useFocusEffect(useCallback(() => {
    void reload();
    void reloadTemplates();
  }, [reload, reloadTemplates]));

  if (loading && !contact) {
    return (
      <AppScreen>
        <View style={styles.centered}>
          <ActivityIndicator color={colors.primary} size="large" />
          <Text style={styles.loadingText}>{t('detail.loading')}</Text>
        </View>
      </AppScreen>
    );
  }

  if (error || !contact) {
    return (
      <AppScreen>
        <AppHeader
          leading={<IconButton accessibilityLabel={t('detail.back')} icon="arrow-back" onPress={navigation.goBack} />}
          title={t('edit.title')}
        />
        <EmptyState
          actionLabel={error ? t('buttons.retry') : undefined}
          description={error ? t('contacts.error.description') : t('detail.notFound.description')}
          icon="person-remove-outline"
          onAction={error ? () => void reload() : undefined}
          title={error ? t('contacts.error.title') : t('detail.notFound.title')}
        />
      </AppScreen>
    );
  }

  const initialValues: ContactFormInput = {
    fullName: contact.fullName,
    phone: contact.phones[0]?.value ?? '',
    email: contact.emails[0]?.value ?? '',
    company: contact.company ?? '',
    title: contact.title ?? '',
    meetingContext: contact.meetingContext ?? '',
    linkedinUrl: contact.linkedinUrl ?? '',
    notes: contact.notes ?? '',
    multiValues: contact.multiValues.flatMap((group) =>
      group.items.map((item) => ({ ...item, fieldKey: group.fieldKey })),
    ),
    customFields: buildContactFormCustomFields([], contact.customFields),
  };

  const saveContact = async (values: ContactFormInput) => {
    await updateContact(database, contact.id, values);
    navigation.goBack();
  };

  return (
    <AppScreen scrollable>
      <AppHeader
        leading={<IconButton accessibilityLabel={t('detail.back')} icon="arrow-back" onPress={navigation.goBack} />}
        subtitle={t('edit.subtitle')}
        title={t('edit.title')}
      />
      <ContactForm
        key={templates.map((template) => template.id).join(':')}
        initialValues={initialValues}
        onSubmit={saveContact}
        submitLabel={t('buttons.saveChanges')}
      />
    </AppScreen>
  );
}

const styles = StyleSheet.create({
  centered: { alignItems: 'center', flex: 1, gap: spacing.md, justifyContent: 'center' },
  loadingText: { color: colors.textMuted, fontSize: typography.body },
});
