import * as DocumentPicker from 'expo-document-picker';
import { File, Paths } from 'expo-file-system';
import * as Sharing from 'expo-sharing';

import type { SmartContactsBackup } from '../data/backupRepository';
import { parseBackupJson } from '../data/backupRepository';

export async function exportBackupFile(backup: SmartContactsBackup): Promise<void> {
  if (!(await Sharing.isAvailableAsync())) throw new Error('SHARING_UNAVAILABLE');
  const date = backup.exportedAt.slice(0, 10);
  const file = new File(Paths.cache, `smart-contacts-backup-${date}.json`);
  file.create({ overwrite: true });
  file.write(JSON.stringify(backup, null, 2));
  await Sharing.shareAsync(file.uri, { dialogTitle: 'Smart Contacts JSON backup', mimeType: 'application/json' });
}

export async function pickBackupFile(): Promise<SmartContactsBackup | null> {
  const result = await DocumentPicker.getDocumentAsync({
    copyToCacheDirectory: true,
    multiple: false,
    type: 'application/json',
  });
  if (result.canceled) return null;
  const raw = await new File(result.assets[0].uri).text();
  return parseBackupJson(raw);
}
