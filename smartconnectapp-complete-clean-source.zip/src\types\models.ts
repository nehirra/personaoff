export type EntityId = string;
export type IsoDateTime = string;
export type BooleanFlag = 0 | 1;
export type CustomFieldValueType = 'text' | 'number' | 'date' | 'url' | 'boolean';

export interface Contact {
  id: EntityId;
  fullName: string;
  company: string | null;
  title: string | null;
  meetingContext: string | null;
  linkedinUrl: string | null;
  photoUri: string | null;
  notes: string | null;
  createdAt: IsoDateTime;
  updatedAt: IsoDateTime;
}

export interface ContactPhone {
  id: EntityId;
  contactId: EntityId;
  value: string;
  label: string | null;
  isPrimary: BooleanFlag;
  createdAt: IsoDateTime;
  updatedAt: IsoDateTime;
}

export interface ContactEmail {
  id: EntityId;
  contactId: EntityId;
  value: string;
  label: string | null;
  isPrimary: BooleanFlag;
  createdAt: IsoDateTime;
  updatedAt: IsoDateTime;
}

export interface ContactMultiValue {
  id: EntityId;
  contactId: EntityId;
  fieldKey: string;
  value: string;
  position: number;
  createdAt: IsoDateTime;
  updatedAt: IsoDateTime;
}

export interface CustomFieldTemplate {
  id: EntityId;
  fieldKey: string;
  label: string;
  valueType: CustomFieldValueType;
  position: number;
  isActive: BooleanFlag;
  createdAt: IsoDateTime;
  updatedAt: IsoDateTime;
}

export interface ContactCustomFieldValue {
  id: EntityId;
  contactId: EntityId;
  templateId: EntityId | null;
  fieldKey: string;
  fieldLabel: string;
  value: string | null;
  valueType: CustomFieldValueType;
  position: number;
  createdAt: IsoDateTime;
  updatedAt: IsoDateTime;
}

export interface UserProfile {
  id: EntityId;
  fullName: string;
  company: string | null;
  title: string | null;
  phone: string | null;
  email: string | null;
  linkedinUrl: string | null;
  photoUri: string | null;
  notes: string | null;
  createdAt: IsoDateTime;
  updatedAt: IsoDateTime;
}
