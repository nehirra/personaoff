export type Migration = {
  version: number;
  name: string;
  sql: string;
};

export const migrations: readonly Migration[] = [
  {
    version: 1,
    name: 'create_app_metadata',
    sql: `
      CREATE TABLE IF NOT EXISTS app_metadata (
        key TEXT PRIMARY KEY NOT NULL,
        value TEXT NOT NULL
      );
    `,
  },
  {
    version: 2,
    name: 'create_contact_schema',
    sql: `
      CREATE TABLE IF NOT EXISTS Contact (
        id TEXT PRIMARY KEY NOT NULL,
        fullName TEXT NOT NULL,
        company TEXT,
        title TEXT,
        meetingContext TEXT,
        linkedinUrl TEXT,
        photoUri TEXT,
        notes TEXT,
        createdAt TEXT NOT NULL,
        updatedAt TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS ContactPhone (
        id TEXT PRIMARY KEY NOT NULL,
        contactId TEXT NOT NULL,
        value TEXT NOT NULL,
        label TEXT,
        isPrimary INTEGER NOT NULL DEFAULT 0 CHECK (isPrimary IN (0, 1)),
        createdAt TEXT NOT NULL,
        updatedAt TEXT NOT NULL,
        FOREIGN KEY (contactId) REFERENCES Contact(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS ContactEmail (
        id TEXT PRIMARY KEY NOT NULL,
        contactId TEXT NOT NULL,
        value TEXT NOT NULL,
        label TEXT,
        isPrimary INTEGER NOT NULL DEFAULT 0 CHECK (isPrimary IN (0, 1)),
        createdAt TEXT NOT NULL,
        updatedAt TEXT NOT NULL,
        FOREIGN KEY (contactId) REFERENCES Contact(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS ContactMultiValue (
        id TEXT PRIMARY KEY NOT NULL,
        contactId TEXT NOT NULL,
        fieldKey TEXT NOT NULL,
        value TEXT NOT NULL,
        position INTEGER NOT NULL DEFAULT 0,
        createdAt TEXT NOT NULL,
        updatedAt TEXT NOT NULL,
        FOREIGN KEY (contactId) REFERENCES Contact(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS CustomFieldTemplate (
        id TEXT PRIMARY KEY NOT NULL,
        fieldKey TEXT NOT NULL UNIQUE,
        label TEXT NOT NULL,
        valueType TEXT NOT NULL DEFAULT 'text' CHECK (valueType IN ('text', 'number', 'date', 'url', 'boolean')),
        position INTEGER NOT NULL DEFAULT 0,
        isActive INTEGER NOT NULL DEFAULT 1 CHECK (isActive IN (0, 1)),
        createdAt TEXT NOT NULL,
        updatedAt TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS ContactCustomFieldValue (
        id TEXT PRIMARY KEY NOT NULL,
        contactId TEXT NOT NULL,
        templateId TEXT,
        fieldKey TEXT NOT NULL,
        fieldLabel TEXT NOT NULL,
        value TEXT,
        valueType TEXT NOT NULL DEFAULT 'text' CHECK (valueType IN ('text', 'number', 'date', 'url', 'boolean')),
        position INTEGER NOT NULL DEFAULT 0,
        createdAt TEXT NOT NULL,
        updatedAt TEXT NOT NULL,
        FOREIGN KEY (contactId) REFERENCES Contact(id) ON DELETE CASCADE,
        FOREIGN KEY (templateId) REFERENCES CustomFieldTemplate(id) ON DELETE SET NULL
      );

      CREATE TABLE IF NOT EXISTS UserProfile (
        id TEXT PRIMARY KEY NOT NULL,
        fullName TEXT NOT NULL,
        company TEXT,
        title TEXT,
        phone TEXT,
        email TEXT,
        linkedinUrl TEXT,
        photoUri TEXT,
        notes TEXT,
        createdAt TEXT NOT NULL,
        updatedAt TEXT NOT NULL
      );

      CREATE INDEX IF NOT EXISTS idx_contact_full_name ON Contact(fullName);
      CREATE INDEX IF NOT EXISTS idx_contact_company ON Contact(company);
      CREATE INDEX IF NOT EXISTS idx_contact_phone_contact_id ON ContactPhone(contactId);
      CREATE INDEX IF NOT EXISTS idx_contact_phone_value ON ContactPhone(value);
      CREATE INDEX IF NOT EXISTS idx_contact_email_contact_id ON ContactEmail(contactId);
      CREATE INDEX IF NOT EXISTS idx_contact_email_value ON ContactEmail(value);
      CREATE INDEX IF NOT EXISTS idx_contact_multi_value_contact_id ON ContactMultiValue(contactId);
      CREATE INDEX IF NOT EXISTS idx_contact_multi_value_key ON ContactMultiValue(fieldKey);
      CREATE INDEX IF NOT EXISTS idx_custom_value_contact_id ON ContactCustomFieldValue(contactId);
      CREATE INDEX IF NOT EXISTS idx_custom_value_template_id ON ContactCustomFieldValue(templateId);
    `,
  },
  {
    version: 3,
    name: 'ensure_unique_contact_template_slots',
    sql: `
      CREATE UNIQUE INDEX IF NOT EXISTS idx_custom_value_contact_template
      ON ContactCustomFieldValue(contactId, templateId)
      WHERE templateId IS NOT NULL;
    `,
  },
];
