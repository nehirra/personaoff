import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, FlatList, StyleSheet, Text, View } from 'react-native';
import { useSQLiteContext } from 'expo-sqlite';

import { colors, spacing, typography } from '../../../app/theme';
import { AppHeader, AppScreen, EmptyState, IconButton, PrimaryButton } from '../../../components';
import { useI18n } from '../../../i18n';
import type { ContactsStackParamList } from '../../../types/navigation';
import { DuplicateReviewRow } from '../components/DuplicateReviewRow';
import {
  applyPreparedImport,
  isImportDecisionComplete,
  prepareContactImport,
  type DuplicateImportItem,
  type ImportDecision,
  type ImportSummary,
  type PreparedImport,
} from '../data/importRepository';
import { deleteImportSession, getImportSession } from '../services/importSessionStore';

type ImportReviewScreenProps = NativeStackScreenProps<ContactsStackParamList, 'ImportReview'>;

export function ImportReviewScreen({ navigation, route }: ImportReviewScreenProps) {
  const { t } = useI18n();
  const database = useSQLiteContext();
  const [prepared, setPrepared] = useState<PreparedImport | null>(null);
  const [decisions, setDecisions] = useState<Record<string, ImportDecision>>({});
  const [loading, setLoading] = useState(true);
  const [applying, setApplying] = useState(false);
  const [error, setError] = useState(false);
  const [summary, setSummary] = useState<ImportSummary | null>(null);

  const prepare = useCallback(async () => {
    const contacts = getImportSession(route.params.sessionId);
    if (!contacts) {
      setError(true);
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(false);
    try {
      setPrepared(await prepareContactImport(database, contacts));
    } catch {
      setError(true);
    } finally {
      setLoading(false);
    }
  }, [database, route.params.sessionId]);

  useEffect(() => { void prepare(); }, [prepare]);

  const completedCount = useMemo(
    () => prepared?.duplicates.filter((item) => isImportDecisionComplete(item, decisions[item.id])).length ?? 0,
    [decisions, prepared],
  );
  const allComplete = Boolean(prepared && completedCount === prepared.duplicates.length);

  const handleDecision = useCallback((itemId: string, decision: ImportDecision) => {
    setDecisions((current) => ({ ...current, [itemId]: decision }));
  }, []);

  const applyImport = async () => {
    if (!prepared || !allComplete) return;
    setApplying(true);
    try {
      const result = await applyPreparedImport(database, prepared, decisions);
      deleteImportSession(route.params.sessionId);
      setSummary(result);
    } catch {
      setError(true);
    } finally {
      setApplying(false);
    }
  };

  const renderItem = useCallback(
    ({ item }: { item: DuplicateImportItem }) => (
      <DuplicateReviewRow
        decision={decisions[item.id]}
        item={item}
        onChange={handleDecision}
      />
    ),
    [decisions, handleDecision],
  );

  if (loading) {
    return (
      <AppScreen>
        <View style={styles.centered}>
          <ActivityIndicator color={colors.primary} size="large" />
          <Text style={styles.statusText}>{t('importReview.preparing')}</Text>
        </View>
      </AppScreen>
    );
  }

  if (summary) {
    return (
      <AppScreen>
        <AppHeader title={t('importReview.summary.title')} />
        <EmptyState
          actionLabel={t('tabs.contacts')}
          description={`${t('importReview.summary.added')}: ${summary.added}  •  ${t('importReview.summary.merged')}: ${summary.merged}`}
          icon="checkmark-circle-outline"
          onAction={() => navigation.popToTop()}
          title={`${summary.total} ${t('importReview.summary.completed')}`}
        />
      </AppScreen>
    );
  }

  if (error || !prepared) {
    return (
      <AppScreen>
        <AppHeader
          leading={<IconButton accessibilityLabel={t('detail.back')} icon="arrow-back" onPress={navigation.goBack} />}
          title={t('importReview.title')}
        />
        <EmptyState
          actionLabel={t('buttons.retry')}
          description={t('importReview.error.description')}
          icon="alert-circle-outline"
          onAction={() => void prepare()}
          title={t('importReview.error.title')}
        />
      </AppScreen>
    );
  }

  return (
    <AppScreen>
      <AppHeader
        leading={<IconButton accessibilityLabel={t('detail.back')} icon="arrow-back" onPress={navigation.goBack} />}
        subtitle={t('importReview.description')}
        title={t('importReview.title')}
      />
      <View style={styles.progress}>
        <Text style={styles.progressText}>
          {completedCount}/{prepared.duplicates.length} {t('importReview.decisionsCompleted')}
        </Text>
        <Text style={styles.newContactsText}>
          {prepared.newContacts.length} {t('importReview.newContacts')}
        </Text>
      </View>
      <FlatList
        contentContainerStyle={styles.list}
        data={prepared.duplicates}
        initialNumToRender={8}
        ItemSeparatorComponent={() => <View style={styles.separator} />}
        keyExtractor={(item) => item.id}
        ListEmptyComponent={
          <Text style={styles.noDuplicates}>{t('importReview.noDuplicates')}</Text>
        }
        maxToRenderPerBatch={8}
        removeClippedSubviews
        renderItem={renderItem}
        showsVerticalScrollIndicator={false}
        windowSize={7}
      />
      <View style={styles.footer}>
        {!allComplete ? <Text style={styles.helper}>{t('importReview.completeAll')}</Text> : null}
        <PrimaryButton
          disabled={!allComplete}
          label={t('importReview.confirm')}
          loading={applying}
          onPress={() => void applyImport()}
        />
      </View>
    </AppScreen>
  );
}

const styles = StyleSheet.create({
  centered: { alignItems: 'center', flex: 1, gap: spacing.md, justifyContent: 'center' },
  statusText: { color: colors.textMuted, fontSize: typography.body },
  progress: { flexDirection: 'row', justifyContent: 'space-between', paddingBottom: spacing.md },
  progressText: { color: colors.primary, flex: 1, fontSize: typography.caption, fontWeight: '700' },
  newContactsText: { color: colors.textMuted, fontSize: typography.caption },
  list: { flexGrow: 1, paddingBottom: spacing.lg },
  separator: { height: spacing.md },
  noDuplicates: { color: colors.textMuted, fontSize: typography.body, padding: spacing.xl, textAlign: 'center' },
  footer: { backgroundColor: colors.background, gap: spacing.sm, paddingBottom: spacing.md, paddingTop: spacing.sm },
  helper: { color: colors.textMuted, fontSize: typography.caption, textAlign: 'center' },
});
