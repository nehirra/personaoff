export type ContactListItem = {
  id: string;
  fullName: string;
  company: string | null;
  title: string | null;
  phone: string | null;
  email: string | null;
  tags: string[];
};

export type ContactDetail = {
  id: string;
  fullName: string;
  company: string | null;
  title: string | null;
  meetingContext: string | null;
  linkedinUrl: string | null;
  photoUri: string | null;
  notes: string | null;
  phones: ContactDetailValue[];
  emails: ContactDetailValue[];
  multiValues: ContactMultiValueGroup[];
  customFields: ContactCustomFieldDetail[];
};

export type ContactDetailValue = {
  id: string;
  label: string | null;
  value: string;
  isPrimary: 0 | 1;
};

export type ContactMultiValueGroup = {
  fieldKey: string;
  items: ContactMultiValueItem[];
};

export type ContactMultiValueItem = {
  id: string;
  value: string;
};

export type ContactCustomFieldDetail = {
  id: string;
  templateId: string | null;
  fieldKey: string;
  fieldLabel: string;
  value: string;
  valueType: 'text' | 'number' | 'date' | 'url' | 'boolean';
};
