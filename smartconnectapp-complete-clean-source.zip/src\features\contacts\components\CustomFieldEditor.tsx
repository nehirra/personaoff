import { Ionicons } from '@expo/vector-icons';
import { Pressable, StyleSheet, Text, View } from 'react-native';

import { colors, radius, spacing, typography } from '../../../app/theme';
import { IconButton, SectionTitle, TextInputField } from '../../../components';
import { useI18n } from '../../../i18n';
import { createId } from '../../../utils/createId';
import type { ContactFormCustomField } from '../data/contactRepository';

type CustomFieldEditorProps = {
  fields: ContactFormCustomField[];
  onChange: (fields: ContactFormCustomField[]) => void;
};

export function CustomFieldEditor({ fields, onChange }: CustomFieldEditorProps) {
  const { t } = useI18n();
  const templateFields = fields.filter((field) => field.templateId !== null);
  const adHocFields = fields.filter((field) => field.templateId === null);

  const updateField = (id: string, patch: Partial<ContactFormCustomField>) => {
    onChange(fields.map((field) => (field.id === id ? { ...field, ...patch } : field)));
  };

  const addAdHocField = () => {
    onChange([
      ...fields,
      {
        id: createId('custom'),
        templateId: null,
        fieldKey: createId('adhoc'),
        fieldLabel: '',
        value: '',
        valueType: 'text',
      },
    ]);
  };

  const removeField = (id: string) => {
    onChange(fields.filter((field) => field.id !== id));
  };

  return (
    <View style={styles.container}>
      <SectionTitle caption={t('templates.formDescription')} title={t('form.customFields')} />

      {templateFields.length > 0 ? (
        <View style={styles.fields}>
          {templateFields.map((field) => (
            <TextInputField
              key={field.id}
              label={field.fieldLabel}
              onChangeText={(value) => updateField(field.id, { value })}
              value={field.value}
            />
          ))}
        </View>
      ) : null}

      <View style={styles.adHocSection}>
        <Text style={styles.adHocTitle}>{t('custom.adHocTitle')}</Text>
        <Text style={styles.adHocDescription}>{t('custom.adHocDescription')}</Text>
        {adHocFields.map((field) => (
          <View key={field.id} style={styles.adHocCard}>
            <View style={styles.adHocHeader}>
              <Text style={styles.adHocCardTitle}>{t('custom.adHocField')}</Text>
              <IconButton
                accessibilityLabel={t('custom.deleteField')}
                icon="trash-outline"
                onPress={() => removeField(field.id)}
              />
            </View>
            <TextInputField
              label={t('custom.key')}
              onChangeText={(fieldLabel) => updateField(field.id, { fieldLabel })}
              placeholder={t('custom.keyPlaceholder')}
              value={field.fieldLabel}
            />
            <TextInputField
              label={t('custom.value')}
              onChangeText={(value) => updateField(field.id, { value })}
              placeholder={t('custom.valuePlaceholder')}
              value={field.value}
            />
          </View>
        ))}
        <Pressable
          accessibilityRole="button"
          onPress={addAdHocField}
          style={({ pressed }) => [styles.addButton, pressed && styles.addButtonPressed]}
        >
          <Ionicons color={colors.primary} name="add" size={18} />
          <Text style={styles.addButtonLabel}>{t('custom.addField')}</Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { gap: spacing.lg },
  fields: { gap: spacing.lg },
  adHocSection: { gap: spacing.md },
  adHocTitle: { color: colors.text, fontSize: typography.body, fontWeight: '700' },
  adHocDescription: { color: colors.textMuted, fontSize: typography.caption, lineHeight: 19 },
  adHocCard: {
    backgroundColor: colors.surface,
    borderColor: colors.border,
    borderRadius: radius.lg,
    borderWidth: 1,
    gap: spacing.md,
    padding: spacing.lg,
  },
  adHocHeader: { alignItems: 'center', flexDirection: 'row', justifyContent: 'space-between' },
  adHocCardTitle: { color: colors.text, fontSize: typography.caption, fontWeight: '700' },
  addButton: {
    alignItems: 'center',
    alignSelf: 'flex-start',
    borderRadius: radius.sm,
    flexDirection: 'row',
    gap: spacing.xs,
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.sm,
  },
  addButtonPressed: { backgroundColor: colors.primarySoft },
  addButtonLabel: { color: colors.primary, fontSize: typography.caption, fontWeight: '700' },
});
