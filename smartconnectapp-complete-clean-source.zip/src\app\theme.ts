export const colors = {
  background: '#F4F6F8',
  surface: '#FFFFFF',
  surfaceMuted: '#EDF1F4',
  text: '#17212B',
  textMuted: '#66717E',
  border: '#DCE2E8',
  primary: '#246B68',
  primaryPressed: '#195654',
  primarySoft: '#DDECEA',
  accent: '#C67B43',
  danger: '#B54747',
  white: '#FFFFFF',
} as const;

export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  xxl: 32,
} as const;

export const radius = {
  sm: 8,
  md: 12,
  lg: 18,
  pill: 999,
} as const;

export const typography = {
  body: 16,
  caption: 13,
  section: 18,
  title: 28,
} as const;
