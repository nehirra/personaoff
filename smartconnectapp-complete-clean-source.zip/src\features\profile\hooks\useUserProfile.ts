import { useCallback, useRef, useState } from 'react';
import { useSQLiteContext } from 'expo-sqlite';

import type { UserProfile } from '../../../types/models';
import { getUserProfile } from '../data/userProfileRepository';

export function useUserProfile() {
  const database = useSQLiteContext();
  const requestId = useRef(0);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const reload = useCallback(async () => {
    const activeRequest = ++requestId.current;
    setLoading(true);
    setError(null);
    try {
      const result = await getUserProfile(database);
      if (activeRequest === requestId.current) setProfile(result);
    } catch (cause) {
      if (activeRequest === requestId.current) {
        setError(cause instanceof Error ? cause : new Error(String(cause)));
      }
    } finally {
      if (activeRequest === requestId.current) setLoading(false);
    }
  }, [database]);

  return { error, loading, profile, reload };
}
