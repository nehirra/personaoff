import { useCallback, useRef, useState } from 'react';
import { useSQLiteContext } from 'expo-sqlite';

import { getContactById } from '../data/contactRepository';
import type { ContactDetail } from '../types';

type ContactDetailState = {
  contact: ContactDetail | null;
  error: Error | null;
  loading: boolean;
};

export function useContactDetail(contactId: string) {
  const database = useSQLiteContext();
  const requestId = useRef(0);
  const [state, setState] = useState<ContactDetailState>({
    contact: null,
    error: null,
    loading: true,
  });

  const reload = useCallback(async () => {
    const activeRequest = ++requestId.current;
    setState((current) => ({ ...current, error: null, loading: true }));

    try {
      const contact = await getContactById(database, contactId);
      if (activeRequest === requestId.current) {
        setState({ contact, error: null, loading: false });
      }
    } catch (cause) {
      if (activeRequest === requestId.current) {
        const error = cause instanceof Error ? cause : new Error(String(cause));
        setState({ contact: null, error, loading: false });
      }
    }
  }, [contactId, database]);

  return { ...state, reload };
}
