import type { BottomTabNavigationProp } from '@react-navigation/bottom-tabs';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import type { CompositeNavigationProp } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useCallback, useState } from 'react';
import { ActivityIndicator, FlatList, StyleSheet, Text, View } from 'react-native';

import { colors, spacing, typography } from '../../../app/theme';
import {
  AppHeader,
  AppScreen,
  Divider,
  EmptyState,
  IconButton,
  SectionTitle,
  TextInputField,
} from '../../../components';
import { useI18n } from '../../../i18n';
import type { ContactsStackParamList, RootTabParamList } from '../../../types/navigation';
import { ContactListRow } from '../components/ContactListRow';
import { useContactList } from '../hooks/useContactList';
import { useDebouncedValue } from '../hooks/useDebouncedValue';
import type { ContactListItem } from '../types';

type ContactsNavigation = CompositeNavigationProp<
  NativeStackNavigationProp<ContactsStackParamList, 'ContactList'>,
  BottomTabNavigationProp<RootTabParamList, 'Contacts'>
>;

export function ContactsScreen() {
  const { t } = useI18n();
  const navigation = useNavigation<ContactsNavigation>();
  const [searchTerm, setSearchTerm] = useState('');
  const debouncedSearchTerm = useDebouncedValue(searchTerm, 250);
  const { contacts, error, loading, reload } = useContactList(debouncedSearchTerm);

  useFocusEffect(
    useCallback(() => {
      void reload();
    }, [reload]),
  );

  const renderContact = useCallback(
    ({ item }: { item: ContactListItem }) => (
      <ContactListRow
        contact={item}
        onPress={() => navigation.navigate('ContactDetail', { contactId: item.id })}
      />
    ),
    [navigation],
  );

  const renderEmptyContent = () => {
    if (loading) {
      return (
        <View style={styles.status}>
          <ActivityIndicator color={colors.primary} size="large" />
          <Text style={styles.statusText}>{t('contacts.loading')}</Text>
        </View>
      );
    }

    if (error) {
      return (
        <EmptyState
          actionLabel={t('buttons.retry')}
          description={t('contacts.error.description')}
          icon="alert-circle-outline"
          onAction={() => void reload()}
          title={t('contacts.error.title')}
        />
      );
    }

    if (debouncedSearchTerm.trim()) {
      return (
        <EmptyState
          description={t('contacts.noResults.description')}
          icon="search-outline"
          title={t('contacts.noResults.title')}
        />
      );
    }

    return (
      <EmptyState
        actionLabel={t('buttons.add')}
        description={t('contacts.empty.description')}
        onAction={() => navigation.navigate('Add')}
        title={t('contacts.empty.title')}
      />
    );
  };

  return (
    <AppScreen>
      <AppHeader
        action={
          <IconButton
            accessibilityLabel={t('buttons.add')}
            icon="person-add-outline"
            onPress={() => navigation.navigate('Add')}
          />
        }
        subtitle={t('contacts.subtitle')}
        title={t('contacts.title')}
      />
      <TextInputField
        autoCapitalize="none"
        autoCorrect={false}
        clearButtonMode="while-editing"
        label={t('contacts.search')}
        onChangeText={setSearchTerm}
        placeholder={t('contacts.search.placeholder')}
        returnKeyType="search"
        value={searchTerm}
      />
      <View style={styles.sectionHeader}>
        <SectionTitle title={t('contacts.section.all')} />
      </View>
      <FlatList
        contentContainerStyle={contacts.length === 0 ? styles.emptyList : styles.list}
        data={contacts}
        ItemSeparatorComponent={() => <Divider compact />}
        keyboardShouldPersistTaps="handled"
        keyExtractor={(item) => item.id}
        ListEmptyComponent={renderEmptyContent}
        initialNumToRender={12}
        maxToRenderPerBatch={12}
        removeClippedSubviews
        renderItem={renderContact}
        showsVerticalScrollIndicator={false}
        windowSize={7}
      />
    </AppScreen>
  );
}

const styles = StyleSheet.create({
  sectionHeader: { marginTop: spacing.xl },
  list: { paddingBottom: spacing.xl },
  emptyList: { flexGrow: 1, justifyContent: 'center', paddingBottom: spacing.xl },
  status: { alignItems: 'center', gap: spacing.md, padding: spacing.xl },
  statusText: { color: colors.textMuted, fontSize: typography.body },
});
