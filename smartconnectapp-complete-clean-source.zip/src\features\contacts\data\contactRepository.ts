import type { SQLiteDatabase } from 'expo-sqlite';

import type {
  ContactCustomFieldDetail,
  ContactDetail,
  ContactDetailValue,
  ContactListItem,
} from '../types';
import { createId } from '../../../utils/createId';

export type ContactFormInput = {
  fullName: string;
  phone: string;
  email: string;
  company: string;
  title: string;
  meetingContext: string;
  linkedinUrl: string;
  notes: string;
  multiValues: ContactFormMultiValue[];
  customFields: ContactFormCustomField[];
};

export type ContactFormMultiValue = {
  id: string;
  fieldKey: string;
  value: string;
};

export type ContactFormCustomField = {
  id: string;
  templateId: string | null;
  fieldKey: string;
  fieldLabel: string;
  value: string;
  valueType: 'text' | 'number' | 'date' | 'url' | 'boolean';
};

type ContactListRow = Omit<ContactListItem, 'tags'> & {
  searchValues: string;
  tagValues: string | null;
};

const TAG_SEPARATOR = '|||';

const CONTACT_LIST_QUERY = `
  SELECT
    c.id,
    c.fullName,
    c.company,
    c.title,
    (
      SELECT p.value
      FROM ContactPhone p
      WHERE p.contactId = c.id
      ORDER BY p.isPrimary DESC, p.createdAt ASC
      LIMIT 1
    ) AS phone,
    (
      SELECT e.value
      FROM ContactEmail e
      WHERE e.contactId = c.id
      ORDER BY e.isPrimary DESC, e.createdAt ASC
      LIMIT 1
    ) AS email,
    (
      SELECT GROUP_CONCAT(tag.value, '${TAG_SEPARATOR}')
      FROM (
        SELECT mv.value
        FROM ContactMultiValue mv
        WHERE mv.contactId = c.id AND TRIM(mv.value) <> ''
        ORDER BY mv.position ASC, mv.createdAt ASC
        LIMIT 2
      ) tag
    ) AS tagValues,
    c.fullName || ' ' ||
    COALESCE(c.company, '') || ' ' ||
    COALESCE(c.title, '') || ' ' ||
    COALESCE(c.meetingContext, '') || ' ' ||
    COALESCE((SELECT GROUP_CONCAT(p.value, ' ') FROM ContactPhone p WHERE p.contactId = c.id), '') || ' ' ||
    COALESCE((SELECT GROUP_CONCAT(e.value, ' ') FROM ContactEmail e WHERE e.contactId = c.id), '') || ' ' ||
    COALESCE((SELECT GROUP_CONCAT(mv.value, ' ') FROM ContactMultiValue mv WHERE mv.contactId = c.id), '') || ' ' ||
    COALESCE((SELECT GROUP_CONCAT(custom.value, ' ') FROM ContactCustomFieldValue custom WHERE custom.contactId = c.id), '')
      AS searchValues
  FROM Contact c
  ORDER BY c.fullName COLLATE NOCASE ASC, c.createdAt DESC;
`;

function foldForSearch(value: string): string {
  return value
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/ı/g, 'i')
    .toLocaleLowerCase();
}

export async function getContacts(
  database: SQLiteDatabase,
  searchTerm: string,
): Promise<ContactListItem[]> {
  const foldedSearch = foldForSearch(searchTerm.trim());
  const rows = await database.getAllAsync<ContactListRow>(CONTACT_LIST_QUERY);

  return rows
    .filter((row) => !foldedSearch || foldForSearch(row.searchValues).includes(foldedSearch))
    .map(({ searchValues: _searchValues, tagValues, ...contact }) => ({
      ...contact,
      tags: tagValues ? tagValues.split(TAG_SEPARATOR).filter(Boolean) : [],
    }));
}

type ContactDetailRow = Omit<ContactDetail, 'phones' | 'emails' | 'multiValues' | 'customFields'>;

type MultiValueRow = {
  id: string;
  fieldKey: string;
  value: string;
};

export async function getContactById(
  database: SQLiteDatabase,
  contactId: string,
): Promise<ContactDetail | null> {
  const contact = await database.getFirstAsync<ContactDetailRow>(
    `SELECT id, fullName, company, title, meetingContext, linkedinUrl, photoUri, notes
     FROM Contact WHERE id = ?`,
    contactId,
  );

  if (!contact) {
    return null;
  }

  const [phones, emails, multiValueRows, customFields] = await Promise.all([
    database.getAllAsync<ContactDetailValue>(
      `SELECT id, label, value, isPrimary FROM ContactPhone
       WHERE contactId = ? AND TRIM(value) <> ''
       ORDER BY isPrimary DESC, createdAt ASC`,
      contactId,
    ),
    database.getAllAsync<ContactDetailValue>(
      `SELECT id, label, value, isPrimary FROM ContactEmail
       WHERE contactId = ? AND TRIM(value) <> ''
       ORDER BY isPrimary DESC, createdAt ASC`,
      contactId,
    ),
    database.getAllAsync<MultiValueRow>(
      `SELECT id, fieldKey, value FROM ContactMultiValue
       WHERE contactId = ? AND TRIM(value) <> ''
       ORDER BY fieldKey COLLATE NOCASE ASC, position ASC, createdAt ASC`,
      contactId,
    ),
    database.getAllAsync<ContactCustomFieldDetail>(
      `SELECT custom.id, custom.templateId, custom.fieldKey, custom.fieldLabel,
              COALESCE(custom.value, '') AS value, custom.valueType
       FROM ContactCustomFieldValue custom
       LEFT JOIN CustomFieldTemplate template ON template.id = custom.templateId
       WHERE custom.contactId = ?
         AND (TRIM(COALESCE(custom.value, '')) <> '' OR COALESCE(template.isActive, 1) = 1)
       ORDER BY custom.position ASC, custom.createdAt ASC`,
      contactId,
    ),
  ]);

  const groupedMultiValues = new Map<string, Array<{ id: string; value: string }>>();
  for (const item of multiValueRows) {
    const items = groupedMultiValues.get(item.fieldKey) ?? [];
    items.push({ id: item.id, value: item.value });
    groupedMultiValues.set(item.fieldKey, items);
  }

  return {
    ...contact,
    phones,
    emails,
    multiValues: Array.from(groupedMultiValues, ([fieldKey, items]) => ({ fieldKey, items })),
    customFields,
  };
}

export async function deleteContact(database: SQLiteDatabase, contactId: string): Promise<void> {
  await database.withTransactionAsync(async () => {
    const result = await database.runAsync('DELETE FROM Contact WHERE id = ?', contactId);
    if (result.changes !== 1) {
      throw new Error('Contact not found');
    }
  });
}

function optionalValue(value: string): string | null {
  const trimmed = value.trim();
  return trimmed || null;
}

async function syncPrimaryContactValue(
  database: SQLiteDatabase,
  table: 'ContactPhone' | 'ContactEmail',
  idPrefix: 'phone' | 'email',
  contactId: string,
  value: string,
  timestamp: string,
): Promise<void> {
  const existing = await database.getFirstAsync<{ id: string }>(
    `SELECT id FROM ${table} WHERE contactId = ? ORDER BY isPrimary DESC, createdAt ASC LIMIT 1`,
    contactId,
  );
  const normalizedValue = value.trim();

  if (normalizedValue) {
    await database.runAsync(`UPDATE ${table} SET isPrimary = 0 WHERE contactId = ?`, contactId);
    if (existing) {
      await database.runAsync(
        `UPDATE ${table} SET value = ?, isPrimary = 1, updatedAt = ? WHERE id = ?`,
        normalizedValue,
        timestamp,
        existing.id,
      );
    } else {
      await database.runAsync(
        `INSERT INTO ${table} (id, contactId, value, label, isPrimary, createdAt, updatedAt)
         VALUES (?, ?, ?, NULL, 1, ?, ?)`,
        createId(idPrefix),
        contactId,
        normalizedValue,
        timestamp,
        timestamp,
      );
    }
    return;
  }

  if (existing) {
    await database.runAsync(`DELETE FROM ${table} WHERE id = ?`, existing.id);
    await database.runAsync(
      `UPDATE ${table} SET isPrimary = 1, updatedAt = ?
       WHERE id = (SELECT id FROM ${table} WHERE contactId = ? ORDER BY createdAt ASC LIMIT 1)`,
      timestamp,
      contactId,
    );
  }
}

function getValidMultiValues(input: ContactFormInput): ContactFormMultiValue[] {
  return input.multiValues
    .map((item) => ({ ...item, fieldKey: item.fieldKey.trim(), value: item.value.trim() }))
    .filter((item) => item.fieldKey && item.value);
}

async function insertMultiValues(
  database: SQLiteDatabase,
  contactId: string,
  input: ContactFormInput,
  timestamp: string,
): Promise<void> {
  const positions = new Map<string, number>();
  for (const item of getValidMultiValues(input)) {
    const position = positions.get(item.fieldKey) ?? 0;
    await database.runAsync(
      `INSERT INTO ContactMultiValue
       (id, contactId, fieldKey, value, position, createdAt, updatedAt)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      item.id,
      contactId,
      item.fieldKey,
      item.value,
      position,
      timestamp,
      timestamp,
    );
    positions.set(item.fieldKey, position + 1);
  }
}

async function syncMultiValues(
  database: SQLiteDatabase,
  contactId: string,
  input: ContactFormInput,
  timestamp: string,
): Promise<void> {
  const validItems = getValidMultiValues(input);
  const existingRows = await database.getAllAsync<{ id: string }>(
    'SELECT id FROM ContactMultiValue WHERE contactId = ?',
    contactId,
  );
  const validIds = new Set(validItems.map((item) => item.id));

  for (const existing of existingRows) {
    if (!validIds.has(existing.id)) {
      await database.runAsync('DELETE FROM ContactMultiValue WHERE id = ? AND contactId = ?', existing.id, contactId);
    }
  }

  const existingIds = new Set(existingRows.map((row) => row.id));
  const positions = new Map<string, number>();
  for (const item of validItems) {
    const position = positions.get(item.fieldKey) ?? 0;
    if (existingIds.has(item.id)) {
      await database.runAsync(
        `UPDATE ContactMultiValue
         SET fieldKey = ?, value = ?, position = ?, updatedAt = ?
         WHERE id = ? AND contactId = ?`,
        item.fieldKey,
        item.value,
        position,
        timestamp,
        item.id,
        contactId,
      );
    } else {
      await database.runAsync(
        `INSERT INTO ContactMultiValue
         (id, contactId, fieldKey, value, position, createdAt, updatedAt)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        item.id,
        contactId,
        item.fieldKey,
        item.value,
        position,
        timestamp,
        timestamp,
      );
    }
    positions.set(item.fieldKey, position + 1);
  }
}

function getPersistedCustomFields(input: ContactFormInput): ContactFormCustomField[] {
  return input.customFields
    .map((field) => ({
      ...field,
      fieldKey: field.fieldKey.trim(),
      fieldLabel: field.fieldLabel.trim(),
      value: field.value.trim(),
    }))
    .filter(
      (field) =>
        field.fieldKey.trim() &&
        field.fieldLabel.trim() &&
        (field.templateId !== null || Boolean(field.value)),
    );
}

async function insertCustomFields(
  database: SQLiteDatabase,
  contactId: string,
  input: ContactFormInput,
  timestamp: string,
): Promise<void> {
  for (const [position, field] of getPersistedCustomFields(input).entries()) {
    await database.runAsync(
      `INSERT INTO ContactCustomFieldValue
       (id, contactId, templateId, fieldKey, fieldLabel, value, valueType, position, createdAt, updatedAt)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      field.id,
      contactId,
      field.templateId,
      field.fieldKey,
      field.fieldLabel,
      optionalValue(field.value),
      field.valueType,
      position,
      timestamp,
      timestamp,
    );
  }
}

async function syncCustomFields(
  database: SQLiteDatabase,
  contactId: string,
  input: ContactFormInput,
  timestamp: string,
): Promise<void> {
  const validFields = getPersistedCustomFields(input);
  const existingRows = await database.getAllAsync<{ id: string }>(
    'SELECT id FROM ContactCustomFieldValue WHERE contactId = ?',
    contactId,
  );
  const validIds = new Set(validFields.map((field) => field.id));
  const existingIds = new Set(existingRows.map((field) => field.id));

  for (const existing of existingRows) {
    if (!validIds.has(existing.id)) {
      await database.runAsync(
        'DELETE FROM ContactCustomFieldValue WHERE id = ? AND contactId = ?',
        existing.id,
        contactId,
      );
    }
  }

  for (const [position, field] of validFields.entries()) {
    if (existingIds.has(field.id)) {
      await database.runAsync(
        `UPDATE ContactCustomFieldValue SET
           templateId = ?, fieldKey = ?, fieldLabel = ?, value = ?, valueType = ?, position = ?, updatedAt = ?
         WHERE id = ? AND contactId = ?`,
        field.templateId,
        field.fieldKey,
        field.fieldLabel,
        optionalValue(field.value),
        field.valueType,
        position,
        timestamp,
        field.id,
        contactId,
      );
    } else {
      await database.runAsync(
        `INSERT INTO ContactCustomFieldValue
         (id, contactId, templateId, fieldKey, fieldLabel, value, valueType, position, createdAt, updatedAt)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        field.id,
        contactId,
        field.templateId,
        field.fieldKey,
        field.fieldLabel,
        optionalValue(field.value),
        field.valueType,
        position,
        timestamp,
        timestamp,
      );
    }
  }
}

export async function createContact(
  database: SQLiteDatabase,
  input: ContactFormInput,
): Promise<string> {
  const contactId = createId('contact');
  const timestamp = new Date().toISOString();

  await database.withTransactionAsync(async () => {
    await database.runAsync(
      `INSERT INTO Contact
       (id, fullName, company, title, meetingContext, linkedinUrl, photoUri, notes, createdAt, updatedAt)
       VALUES (?, ?, ?, ?, ?, ?, NULL, ?, ?, ?)`,
      contactId,
      input.fullName.trim(),
      optionalValue(input.company),
      optionalValue(input.title),
      optionalValue(input.meetingContext),
      optionalValue(input.linkedinUrl),
      optionalValue(input.notes),
      timestamp,
      timestamp,
    );
    await syncPrimaryContactValue(database, 'ContactPhone', 'phone', contactId, input.phone, timestamp);
    await syncPrimaryContactValue(database, 'ContactEmail', 'email', contactId, input.email, timestamp);
    await insertMultiValues(database, contactId, input, timestamp);
    await insertCustomFields(database, contactId, input, timestamp);
  });

  return contactId;
}

export async function updateContact(
  database: SQLiteDatabase,
  contactId: string,
  input: ContactFormInput,
): Promise<void> {
  const timestamp = new Date().toISOString();

  await database.withTransactionAsync(async () => {
    const result = await database.runAsync(
      `UPDATE Contact SET
         fullName = ?, company = ?, title = ?, meetingContext = ?, linkedinUrl = ?, notes = ?, updatedAt = ?
       WHERE id = ?`,
      input.fullName.trim(),
      optionalValue(input.company),
      optionalValue(input.title),
      optionalValue(input.meetingContext),
      optionalValue(input.linkedinUrl),
      optionalValue(input.notes),
      timestamp,
      contactId,
    );
    if (result.changes !== 1) {
      throw new Error('Contact not found');
    }

    await syncPrimaryContactValue(database, 'ContactPhone', 'phone', contactId, input.phone, timestamp);
    await syncPrimaryContactValue(database, 'ContactEmail', 'email', contactId, input.email, timestamp);
    await syncMultiValues(database, contactId, input, timestamp);
    await syncCustomFields(database, contactId, input, timestamp);
  });
}
