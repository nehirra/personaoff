import { StyleSheet, Text, View } from 'react-native';

import { colors, spacing, typography } from '../app/theme';

type SectionTitleProps = {
  caption?: string;
  title: string;
};

export function SectionTitle({ caption, title }: SectionTitleProps) {
  return (
    <View style={styles.container}>
      <Text numberOfLines={2} style={styles.title}>{title}</Text>
      {caption ? <Text numberOfLines={3} style={styles.caption}>{caption}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { gap: spacing.xs },
  title: { color: colors.text, fontSize: typography.section, fontWeight: '700' },
  caption: { color: colors.textMuted, fontSize: typography.caption, lineHeight: 19 },
});
