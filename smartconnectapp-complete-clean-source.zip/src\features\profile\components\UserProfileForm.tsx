import { useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';

import { colors, spacing, typography } from '../../../app/theme';
import { PrimaryButton, TextInputField } from '../../../components';
import { useI18n } from '../../../i18n';
import type { UserProfileInput } from '../data/userProfileRepository';

type UserProfileFormProps = {
  initialValues: UserProfileInput;
  onSubmit: (values: UserProfileInput) => Promise<void>;
};

type FormErrors = Partial<Record<keyof UserProfileInput | 'form', string>>;

function isValidPhone(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  return /^[+\d\s().-]+$/.test(value) && digits.length >= 7 && digits.length <= 15;
}

function isValidEmail(value: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

function isValidUrl(value: string): boolean {
  return /^(https?:\/\/)?[\w.-]+\.[a-z]{2,}(\/\S*)?$/i.test(value);
}

export function UserProfileForm({ initialValues, onSubmit }: UserProfileFormProps) {
  const { t } = useI18n();
  const [values, setValues] = useState(initialValues);
  const [errors, setErrors] = useState<FormErrors>({});
  const [saving, setSaving] = useState(false);

  const setField = (field: keyof UserProfileInput, value: string) => {
    setValues((current) => ({ ...current, [field]: value }));
    setErrors((current) => ({ ...current, [field]: undefined, form: undefined }));
  };

  const submit = async () => {
    const nextErrors: FormErrors = {};
    if (!values.fullName.trim()) nextErrors.fullName = t('errors.required');
    if (values.phone.trim() && !isValidPhone(values.phone.trim())) nextErrors.phone = t('errors.invalidPhone');
    if (values.email.trim() && !isValidEmail(values.email.trim())) nextErrors.email = t('errors.invalidEmail');
    if (values.linkedinUrl.trim() && !isValidUrl(values.linkedinUrl.trim())) nextErrors.linkedinUrl = t('errors.invalidUrl');
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;

    setSaving(true);
    try {
      await onSubmit(values);
    } catch {
      setErrors({ form: t('userProfile.saveError') });
    } finally {
      setSaving(false);
    }
  };

  return (
    <View style={styles.form}>
      <TextInputField
        autoCapitalize="words"
        error={errors.fullName}
        label={t('form.fullName')}
        onChangeText={(value) => setField('fullName', value)}
        value={values.fullName}
      />
      <TextInputField
        error={errors.phone}
        keyboardType="phone-pad"
        label={t('form.phone')}
        onChangeText={(value) => setField('phone', value)}
        value={values.phone}
      />
      <TextInputField
        autoCapitalize="none"
        autoCorrect={false}
        error={errors.email}
        keyboardType="email-address"
        label={t('form.email')}
        onChangeText={(value) => setField('email', value)}
        value={values.email}
      />
      <TextInputField
        autoCapitalize="words"
        label={t('form.company')}
        onChangeText={(value) => setField('company', value)}
        value={values.company}
      />
      <TextInputField
        autoCapitalize="words"
        label={t('form.title')}
        onChangeText={(value) => setField('title', value)}
        value={values.title}
      />
      <TextInputField
        autoCapitalize="none"
        autoCorrect={false}
        error={errors.linkedinUrl}
        keyboardType="url"
        label={t('form.linkedinUrl')}
        onChangeText={(value) => setField('linkedinUrl', value)}
        value={values.linkedinUrl}
      />
      <TextInputField
        label={t('userProfile.bio')}
        multiline
        onChangeText={(value) => setField('notes', value)}
        value={values.notes}
      />
      {errors.form ? <Text style={styles.formError}>{errors.form}</Text> : null}
      <PrimaryButton label={t('buttons.save')} loading={saving} onPress={() => void submit()} />
    </View>
  );
}

const styles = StyleSheet.create({
  form: { gap: spacing.lg },
  formError: { color: colors.danger, fontSize: typography.caption, textAlign: 'center' },
});
