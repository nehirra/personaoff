import { Ionicons } from '@expo/vector-icons';
import { Pressable, StyleSheet, Text, View } from 'react-native';

import { colors, radius, spacing, typography } from '../../../app/theme';
import { IconButton, SectionTitle, TextInputField } from '../../../components';
import { useI18n } from '../../../i18n';
import { createId } from '../../../utils/createId';
import type { ContactFormMultiValue } from '../data/contactRepository';

type MultiValueEditorProps = {
  items: ContactFormMultiValue[];
  onChange: (items: ContactFormMultiValue[]) => void;
};

const defaultFieldKeys = ['sector', 'hobby', 'interest'] as const;

export function MultiValueEditor({ items, onChange }: MultiValueEditorProps) {
  const { t } = useI18n();
  const extraFieldKeys = items
    .map((item) => item.fieldKey)
    .filter((key, index, keys) => !defaultFieldKeys.includes(key as never) && keys.indexOf(key) === index);
  const fieldKeys = [...defaultFieldKeys, ...extraFieldKeys];

  const getFieldLabel = (fieldKey: string): string => {
    if (fieldKey === 'sector') return t('multi.sector');
    if (fieldKey === 'hobby') return t('multi.hobbies');
    if (fieldKey === 'interest') return t('multi.interests');
    return fieldKey;
  };

  const addItem = (fieldKey: string) => {
    onChange([...items, { id: createId('multi'), fieldKey, value: '' }]);
  };

  const updateItem = (id: string, value: string) => {
    onChange(items.map((item) => (item.id === id ? { ...item, value } : item)));
  };

  const removeItem = (id: string) => {
    onChange(items.filter((item) => item.id !== id));
  };

  return (
    <View style={styles.container}>
      <SectionTitle caption={t('multi.description')} title={t('multi.title')} />
      {fieldKeys.map((fieldKey) => {
        const fieldItems = items.filter((item) => item.fieldKey === fieldKey);
        const fieldLabel = getFieldLabel(fieldKey);
        return (
          <View key={fieldKey} style={styles.group}>
            <Text style={styles.groupTitle}>{fieldLabel}</Text>
            {fieldItems.map((item, index) => (
              <View key={item.id} style={styles.valueRow}>
                <View style={styles.valueInput}>
                  <TextInputField
                    label={`${fieldLabel} ${index + 1}`}
                    onChangeText={(value) => updateItem(item.id, value)}
                    value={item.value}
                  />
                </View>
                <View style={styles.deleteAction}>
                  <IconButton
                    accessibilityLabel={t('multi.deleteValue')}
                    icon="trash-outline"
                    onPress={() => removeItem(item.id)}
                  />
                </View>
              </View>
            ))}
            <Pressable
              accessibilityRole="button"
              onPress={() => addItem(fieldKey)}
              style={({ pressed }) => [styles.addButton, pressed && styles.addButtonPressed]}
            >
              <Ionicons color={colors.primary} name="add" size={18} />
              <Text style={styles.addButtonLabel}>{t('multi.addValue')}</Text>
            </Pressable>
          </View>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { gap: spacing.lg },
  group: {
    backgroundColor: colors.surface,
    borderColor: colors.border,
    borderRadius: radius.lg,
    borderWidth: 1,
    gap: spacing.md,
    padding: spacing.lg,
  },
  groupTitle: { color: colors.text, fontSize: typography.body, fontWeight: '700' },
  valueRow: { alignItems: 'flex-end', flexDirection: 'row', gap: spacing.sm },
  valueInput: { flex: 1, minWidth: 0 },
  deleteAction: { paddingBottom: 3 },
  addButton: {
    alignItems: 'center',
    alignSelf: 'flex-start',
    borderRadius: radius.sm,
    flexDirection: 'row',
    gap: spacing.xs,
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.sm,
  },
  addButtonPressed: { backgroundColor: colors.primarySoft },
  addButtonLabel: { color: colors.primary, fontSize: typography.caption, fontWeight: '700' },
});
