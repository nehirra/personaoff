import { useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';

import { colors, spacing, typography } from '../../../app/theme';
import { Divider, PrimaryButton, SectionTitle, TextInputField } from '../../../components';
import { useI18n } from '../../../i18n';
import type { ContactFormInput } from '../data/contactRepository';
import { MultiValueEditor } from './MultiValueEditor';
import { CustomFieldEditor } from './CustomFieldEditor';

export const emptyContactForm: ContactFormInput = {
  fullName: '',
  phone: '',
  email: '',
  company: '',
  title: '',
  meetingContext: '',
  linkedinUrl: '',
  notes: '',
  multiValues: [],
  customFields: [],
};

type FormErrors = Partial<Record<keyof ContactFormInput | 'form', string>>;

type ContactFormProps = {
  initialValues?: ContactFormInput;
  onSubmit: (values: ContactFormInput) => Promise<void>;
  submitLabel: string;
};

function isValidPhone(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  return /^[+\d\s().-]+$/.test(value) && digits.length >= 7 && digits.length <= 15;
}

function isValidEmail(value: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

function isValidUrl(value: string): boolean {
  return /^(https?:\/\/)?[\w.-]+\.[a-z]{2,}(\/\S*)?$/i.test(value);
}

export function ContactForm({ initialValues = emptyContactForm, onSubmit, submitLabel }: ContactFormProps) {
  const { t } = useI18n();
  const [values, setValues] = useState<ContactFormInput>(initialValues);
  const [errors, setErrors] = useState<FormErrors>({});
  const [saving, setSaving] = useState(false);

  const setField = (field: keyof ContactFormInput, value: string) => {
    setValues((current) => ({ ...current, [field]: value }));
    setErrors((current) => ({ ...current, [field]: undefined, form: undefined }));
  };

  const validate = (): FormErrors => {
    const nextErrors: FormErrors = {};
    if (!values.fullName.trim()) nextErrors.fullName = t('errors.required');
    if (values.phone.trim() && !isValidPhone(values.phone.trim())) nextErrors.phone = t('errors.invalidPhone');
    if (values.email.trim() && !isValidEmail(values.email.trim())) nextErrors.email = t('errors.invalidEmail');
    if (values.linkedinUrl.trim() && !isValidUrl(values.linkedinUrl.trim())) nextErrors.linkedinUrl = t('errors.invalidUrl');
    return nextErrors;
  };

  const submit = async () => {
    const nextErrors = validate();
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;

    setSaving(true);
    try {
      await onSubmit(values);
      setValues(initialValues);
      setErrors({});
    } catch {
      setErrors({ form: t('errors.saveContact') });
    } finally {
      setSaving(false);
    }
  };

  return (
    <View>
      <SectionTitle title={t('add.details.title')} />
      <View style={styles.form}>
        <TextInputField
          autoCapitalize="words"
          error={errors.fullName}
          label={t('form.fullName')}
          onChangeText={(value) => setField('fullName', value)}
          value={values.fullName}
        />
        <TextInputField
          error={errors.phone}
          keyboardType="phone-pad"
          label={t('form.phone')}
          onChangeText={(value) => setField('phone', value)}
          value={values.phone}
        />
        <TextInputField
          autoCapitalize="none"
          autoCorrect={false}
          error={errors.email}
          keyboardType="email-address"
          label={t('form.email')}
          onChangeText={(value) => setField('email', value)}
          value={values.email}
        />
        <Divider />
        <TextInputField
          autoCapitalize="words"
          label={t('form.company')}
          onChangeText={(value) => setField('company', value)}
          value={values.company}
        />
        <TextInputField
          autoCapitalize="words"
          label={t('form.title')}
          onChangeText={(value) => setField('title', value)}
          value={values.title}
        />
        <TextInputField
          label={t('form.meetingContext')}
          multiline
          onChangeText={(value) => setField('meetingContext', value)}
          value={values.meetingContext}
        />
        <TextInputField
          autoCapitalize="none"
          autoCorrect={false}
          error={errors.linkedinUrl}
          keyboardType="url"
          label={t('form.linkedinUrl')}
          onChangeText={(value) => setField('linkedinUrl', value)}
          value={values.linkedinUrl}
        />
        <Divider />
        <MultiValueEditor
          items={values.multiValues}
          onChange={(multiValues) => setValues((current) => ({ ...current, multiValues }))}
        />
        <Divider />
        <CustomFieldEditor
          fields={values.customFields}
          onChange={(customFields) => setValues((current) => ({ ...current, customFields }))}
        />
        {values.customFields.length > 0 ? <Divider /> : null}
        <TextInputField
          label={t('form.notes')}
          multiline
          onChangeText={(value) => setField('notes', value)}
          value={values.notes}
        />
        {errors.form ? <Text style={styles.formError}>{errors.form}</Text> : null}
        <PrimaryButton label={submitLabel} loading={saving} onPress={() => void submit()} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  form: { gap: spacing.lg, marginTop: spacing.lg },
  formError: { color: colors.danger, fontSize: typography.caption, textAlign: 'center' },
});
