import {
  Contact,
  ContactField,
  ContactsSortOrder,
  requestPermissionsAsync,
} from 'expo-contacts';

export type ImportedContactValue = {
  label: string | null;
  value: string;
};

export type ImportedDeviceContact = {
  sourceId: string;
  fullName: string;
  company: string | null;
  title: string | null;
  phones: ImportedContactValue[];
  emails: ImportedContactValue[];
};

export type DeviceContactsReadResult =
  | { status: 'denied'; canAskAgain: boolean }
  | { status: 'granted'; contacts: ImportedDeviceContact[] };

type NativeContactInput = {
  id: string;
  fullName?: string | null;
  givenName?: string | null;
  familyName?: string | null;
  company?: string | null;
  jobTitle?: string | null;
  phones?: Array<{ label?: string; number?: string }>;
  emails?: Array<{ label?: string; address?: string }>;
};

const requestedFields = [
  ContactField.FULL_NAME,
  ContactField.GIVEN_NAME,
  ContactField.FAMILY_NAME,
  ContactField.COMPANY,
  ContactField.JOB_TITLE,
  ContactField.PHONES,
  ContactField.EMAILS,
] as const;

function normalizePhone(value: string): string {
  const trimmed = value.trim();
  const digits = trimmed.replace(/\D/g, '');
  return trimmed.startsWith('+') && digits ? `+${digits}` : digits;
}

function uniqueValues(values: ImportedContactValue[]): ImportedContactValue[] {
  const seen = new Set<string>();
  return values.filter((item) => {
    if (!item.value || seen.has(item.value)) return false;
    seen.add(item.value);
    return true;
  });
}

export function normalizeDeviceContact(contact: NativeContactInput): ImportedDeviceContact | null {
  const phones = uniqueValues(
    (contact.phones ?? []).map((phone) => ({
      label: phone.label?.trim() || null,
      value: normalizePhone(phone.number ?? ''),
    })),
  );
  const emails = uniqueValues(
    (contact.emails ?? []).map((email) => ({
      label: email.label?.trim() || null,
      value: (email.address ?? '').trim().toLocaleLowerCase(),
    })),
  );
  const composedName = [contact.givenName, contact.familyName]
    .map((part) => part?.trim())
    .filter(Boolean)
    .join(' ');
  const fullName =
    contact.fullName?.trim() ||
    composedName ||
    contact.company?.trim() ||
    phones[0]?.value ||
    emails[0]?.value ||
    '';

  if (!fullName) return null;

  return {
    sourceId: contact.id,
    fullName,
    company: contact.company?.trim() || null,
    title: contact.jobTitle?.trim() || null,
    phones,
    emails,
  };
}

export async function requestAndReadDeviceContacts(): Promise<DeviceContactsReadResult> {
  const permission = await requestPermissionsAsync();
  if (permission.status !== 'granted') {
    return { status: 'denied', canAskAgain: permission.canAskAgain };
  }

  const contacts: ImportedDeviceContact[] = [];
  const pageSize = 500;
  let offset = 0;

  while (true) {
    const batch = await Contact.getAllDetails(requestedFields, {
      limit: pageSize,
      offset,
      sortOrder: ContactsSortOrder.UserDefault,
    });
    for (const nativeContact of batch) {
      const normalized = normalizeDeviceContact(nativeContact);
      if (normalized) contacts.push(normalized);
    }
    if (batch.length < pageSize) break;
    offset += batch.length;
  }

  return { status: 'granted', contacts };
}
